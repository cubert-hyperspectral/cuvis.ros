
/**
 @file cuvis.h
 SDK calls for cuvis C SDKis header defines all public C SDK functions and data types
 */

/** \addtogroup cuvis_log Logging
##Log configuration
When a local ".cuvis" directory exists with an empty "log.cfg" file, the cuvis.dll will create a debug log in that directory. 

The log file name is the process name followed by log, e.g. "example.exe.log", if the process is named "example.log"

If a local ".cuvis" directory is not found, the system-wide configuration of the logging is used (activated by default from the installation of cuvis):
The configuration can be found under %PROGRAMDATA%/cuvis/log.cfg (usually "C:/Program Data/cuvis/log.cfg") for windwos or /etc/cuvis/log.cfg for linux. The log output can be found under %PROGRAMDATA%/cuvis for windows and /var/log for linux.


*/

/** \addtogroup cuvis_examples Examples
##Overview
*
* With the SDK several examples are installed. Under Windows you can find the examples in your installation directory (Default: "C:\Program Files\Cuvis\sdk\cuvis_c\examples" or "C:\Program Files\Cuvis\sdk\cuvis_cpp\examples"), 
* under Linux they can be found in "/lib/cuvis/cuvis_c/examples" or "/lib/cuvis/cuvis_cpp/examples" . \n
* Each Example comes with the precompiled binary, a short .sh-script to run the application and the source code file. The .sh-script requires the bash console. Under windows we recommend to use Git Bash. \n
* Examples 01-04 require the "sample_data" folder to be present in the installation directory ( Windows: "C:\Program Files\Cuvis\sdk\sample_data" , Linux: "/lib/cuvis/sample_data"). \n
* Examples 05-06 require a camera to be installed and connected. \n
*
##Compiling examples
* Instead of using the precompiled examples, you can use the provided source code to compile it yourself. Under Linux this is quite simple. \n
   *    - for cuvis_c examples:
   *         -#  sudo apt install gcc
   *         -# sudo gcc -o 0X_example main.c  -L/lib/cuvis -lcuvis
   *    - for cuvis_cpp examples:
   *         -# sudo apt install g++
   *         -# sudo g++ -o 0X_example main.cpp  -L/lib/cuvis -lcuvis -std=c++17

*
* ##01_loadMeasurement
* Load measurement from disk and print the value (count) for all available channels (wavelength) for one specific pixel.
* ##02_reprocessMeasurement
* Load measurement as well as references (dark, white, distance) from disk and reprocess the measurement to e.g. reflectance.
* ##03_exportMeasurement
* Load measurement from disk and save to different file formats.
* ##04_changeDistance
* Load measurement from disk and reprocess to a new distance.
* ##05_recordSingleImages
* Setup camera and record measurements via software trigger, aka "single shot mode" or "software mode".
* ##06_recordVideo
* Setup camera and record measurements via internal clock triggering, aka "video mode". In this example the worker is used to make use of multithreading (\ref cuvis_worker_create).
*/

#ifndef CUVIS_SDK_C_H
#define CUVIS_SDK_C_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
/** The cuvis namespace contains all SDK functions. */
#endif

/* Supress security warnings */
#define _CRT_SECURE_NO_WARNINGS
/* API MACROS */

#ifdef _WIN32
  #ifdef CUVIS_SDK_CLIBRARY_EXPORTS
    #define SDK_CAPI __declspec(dllexport)
  #else
    #define SDK_CAPI __declspec(dllimport)
  #endif

  #ifdef __cplusplus
    #define SDK_CCALL __cdecl
  #else
    #define SDK_CCALL
  #endif
#else
  #define SDK_CAPI
  #define SDK_CCALL
#endif

/* FUNCTION MACROS */

/** macro for creating allocate and free functions for c data structures*/
#define ALLOCATE_AND_FREE(DATATYPE, NAME)                     \
  /** Allocate function for DATATYPE. */                      \
  SDK_CAPI DATATYPE* SDK_CCALL cuvis_##NAME##_allocate(void); \
  /** Free function for DATATYPE */                           \
  SDK_CAPI void SDK_CCALL cuvis_##NAME##_free(DATATYPE* ptr);

/** macro for creating acquisition getter functions */
#define ACQ_GET_SINGLE_VALUE(NAME, TYPE, COMMENT)                            \
  /** Get NAME function. Details: COMMENT\n Result is written to o_pvalue */ \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_get(CUVIS_ACQ_CONT i_acqCont, TYPE* o_pvalue);

/** macro for creating stubs of sync and async acquisition setter functions */
#define ACQ_SET_SINGLE_VALUE(NAME, TYPE, UNIT_STR)                                            \
  /** set NAME. Unit: UNIT_STR\n Block until done or failed  */                               \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_set(CUVIS_ACQ_CONT i_acqCont, TYPE value);           \
  /** set NAME asynchronously. Unit: UNIT_STR\n Use @ref cuvis_async_call_get to sync again*/ \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_set_async(CUVIS_ACQ_CONT i_acqCont, CUVIS_ASYNC_CALL_RESULT* o_pAsyncResult, TYPE value);

/** macro for creating acquisition-component getter functions */
#define COMP_GET_SINGLE_VALUE(NAME, TYPE, COMMENT)                           \
  /** Get NAME function. Details: COMMENT\n Result is written to o_pvalue */ \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_get(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_id, TYPE* o_pvalue);

/** macro for creating stubs of sync and async acquisition-component setter functions */
#define COMP_SET_SINGLE_VALUE(NAME, TYPE, UNIT_STR)                                                 \
  /** set NAME. Unit: UNIT_STR\n Block until done or failed  */                                     \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_set(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_id, TYPE value); \
  /** set NAME asynchronously. Unit: UNIT_STR\n Use @ref cuvis_async_call_get to sync again*/       \
  SDK_CAPI CUVIS_STATUS SDK_CCALL NAME##_set_async(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_id, CUVIS_ASYNC_CALL_RESULT* o_pAsyncResult, TYPE value);

/* SIMPLE TYPES */

/** */
#define CUVIS_INT int32_t

/** handle */
#define CUVIS_HANDLE CUVIS_INT

/** handle value of 0 is reserved for invalid handles */
#define CUVIS_HANDLE_NULL CUVIS_HANDLE(0)

/** placeholder data type*/
#define CUVIS_MISC_PTR void*

/** */
#define CUVIS_CHAR char

/** */
#define CUVIS_WCHAR wchar_t

/** max string buffer length (e.g. for paths) */
#define CUVIS_MAXBUF 256

/** cstring data type definition */
#define CUVIS_STRING CUVIS_CHAR[CUVIS_MAXBUF]

/** field for binary flags */
#define CUVIS_FLAGS uint32_t

/** time since epoch in millisecond steps */
#define CUVIS_TIMESTAMP uint64_t

/** measurement handle */
#define CUVIS_MESU CUVIS_HANDLE

/** measurement session_info file handle */
#define CUVIS_SESSION_FILE CUVIS_HANDLE

/** calibration handle */
#define CUVIS_CALIB CUVIS_HANDLE

/** acquisition context handle */
#define CUVIS_ACQ_CONT CUVIS_HANDLE

/** processing context handle */
#define CUVIS_PROC_CONT CUVIS_HANDLE

/** exporter handle (all exporter types) */
#define CUVIS_EXPORTER CUVIS_HANDLE

/** data viewer handle */
#define CUVIS_VIEWER CUVIS_HANDLE

/** data viewer result handle (view) */
#define CUVIS_VIEW CUVIS_HANDLE

/** worker handle */
#define CUVIS_WORKER CUVIS_HANDLE

/** @brief handle to an async function call result.

A handle can be checked by the function @ref cuvis_async_call_get */
#define CUVIS_ASYNC_CALL_RESULT CUVIS_HANDLE

/** @brief handle to an async capture result.

A handle can be checked by the function @ref cuvis_async_capture_get */
#define CUVIS_ASYNC_CAPTURE_RESULT CUVIS_HANDLE

/** @brief holds capabilities for operation mode as flags
*/
#define CUVIS_MODE_CAPABILITIES CUVIS_INT

/* CONSTANTS AND FLAGS */

/* TODO add documentation */
#define CUVIS_MODE_CAPABILITY_ACQUISITION_CAPTURE 1
#define CUVIS_MODE_CAPABILITY_ACQUISITION_TIMELAPSE 2
#define CUVIS_MODE_CAPABILITY_ACQUISITION_CONTINUOUS 4
#define CUVIS_MODE_CAPABILITY_ACQUISITION_SNAPSHOT 8
#define CUVIS_MODE_CAPABILITY_ACQUISITION_SETINTEGRATIONTIME 16
#define CUVIS_MODE_CAPABILITY_ACQUISITION_SETGAIN 32
#define CUVIS_MODE_CAPABILITY_ACQUISITION_AVERAGING 64
#define CUVIS_MODE_CAPABILITY_PROCESSING_SENSOR_RAW 128
#define CUVIS_MODE_CAPABILITY_PROCESSING_CUBE_RAW 256
#define CUVIS_MODE_CAPABILITY_PROCESSING_CUBE_REF 512
#define CUVIS_MODE_CAPABILITY_PROCESSING_CUBE_DARKSUBTRACT 1024
#define CUVIS_MODE_CAPABILITY_PROCESSING_CUBE_FLATFIELDING 2048
#define CUVIS_MODE_CAPABILITY_PROCESSING_CUBE_SPECTRALRADIANCE 4096
#define CUVIS_MODE_CAPABILITY_PROCESSING_SAVE_FILE 8192
#define CUVIS_MODE_CAPABILITY_PROCESSING_CLEAR_RAW 16384
#define CUVIS_MODE_CAPABILITY_PROCESSING_CALC_LIVE 32768
#define CUVIS_MODE_CAPABILITY_PROCESSING_AUTOEXPOSURE 65536
#define CUVIS_MODE_CAPABILITY_PROCESSING_ORIENTATION 131072
#define CUVIS_MODE_CAPABILITY_PROCESSING_SET_WHITE 262144
#define CUVIS_MODE_CAPABILITY_PROCESSING_SET_DARK 524288
#define CUVIS_MODE_CAPABILITY_PROCESSING_SET_SPRADCALIB 1048576
#define CUVIS_MODE_CAPABILITY_PROCESSING_SET_DISTANCECALIB 2097152
#define CUVIS_MODE_CAPABILITY_PROCESSING_SET_DISTANCE_VALUE 4194304
#define CUVIS_MODE_CAPABILITY_PROCESSING_USE_DARK_SPRADCALIB 8388608
#define CUVIS_MODE_CAPABILITY_PROCESSING_USE_WHITE_SPRADCALIB 16777216
#define CUVIS_MODE_CAPABILITY_PROCESSING_REQUIRE_WHITEDARK_REFLECTANCE 33554432

//todo documentation
enum cuvis_capabilities_t
{
  AcquisitionCapture = 1,
  AcquisitionTimelapse = 2,
  AcquisitionContinuous = 4,
  AcquisitionSnapshot = 8,
  AcquisitionSetIntegrationtime = 16,
  AcquisitionSetGain = 32,
  AcquisitionAveraging = 64,
  ProcessingSensorRaw = 128,
  ProcessingCubeRaw = 256,
  ProcessingCubeRef = 512,
  ProcessingCubeDarkSubtract = 1024,
  ProcessingCubeFlatFielding = 2048,
  ProcessingCubeSpectralRadiance = 4096,
  ProcessingSaveFile = 8192,
  ProcessingClearRaw = 16384,
  ProcessingCalcLive = 32768,
  ProcessingAutoExposure = 65536,
  ProcessingOrientation = 131072,
  ProcessingSetWhite = 262144,
  ProcessingSetDark = 524288,
  ProcessingSetSprad = 1048576,
  ProcessingSetDistanceCalib = 2097152,
  ProcessingSetDistanceValue = 4194304,
  ProcessingUseDarkSpradcalib = 8388608,
  ProcessingUseWhiteSpradCalib = 16777216,
  ProcessingRequireWhiteDarkReflectance = 33554432
};

/** @brief the measurement was over-illuminated

    One of the devices sensor data points were over-saturated while recording
    This may not be directly visible in the data cube, as the sensor data needs
    extensive processing.
    @note only the spectral data is checked. The pan image's saturation is not checked.

    If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_OVERILLUMINATED_KEY
    */
#define CUVIS_MESU_FLAG_OVERILLUMINATED 1

/** @brief A reference measurement used has poor quality

One or more of the reference measurements used had a poor data quality.
This may lead to invalid results.

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_POOR_REFERENCE_KEY
*/
#define CUVIS_MESU_FLAG_POOR_REFERENCE 2

/** @brief the white balancing detected bad data

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_POOR_WHITE_BALANCING_KEY
*/
#define CUVIS_MESU_FLAG_POOR_WHITE_BALANCING 4

/** the dark's integration time does not match the measurement

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_DARK_INTTIME_KEY
*/
#define CUVIS_MESU_FLAG_DARK_INTTIME 8

/** the sensor temperature at dark's recording does not match measurement's recording device temperature

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_DARK_TEMP_KEY
*/
#define CUVIS_MESU_FLAG_DARK_TEMP 16

/** the white's integration time does not match the measurement

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_WHITE_INTTIME_KEY
*/
#define CUVIS_MESU_FLAG_WHITE_INTTIME 32

/** the sensor temperature at white's recording does not match measurement's recording device temperature

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_WHITE_TEMP_KEY
*/
#define CUVIS_MESU_FLAG_WHITE_TEMP 64

/** the white's dark integration time does not match the measurement

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_WHITEDARK_INTTIME_KEY
*/
#define CUVIS_MESU_FLAG_WHITEDARK_INTTIME 128

/** the sensor temperature at white's dark recording does not match measurement's recording device temperature

If this flag is set, additional information can retrieved by calling
@ref cuvis_measurement_get_data_sensor_info with the key @ref CUVIS_MESU_FLAG_WHITEDARK_TEMP_KEY
*/
#define CUVIS_MESU_FLAG_WHITEDARK_TEMP 256

/** \addtogroup cuvis_reserved_keys Reserved Keys
 *  @{
*/

/** name of the data field for the hyperspectral cube (in all modes except @ref Preview) */
#define CUVIS_MESU_CUBE_KEY "cube"

/** name of the pan image (pixels registered to  @ref CUVIS_MESU_CUBE_KEY)*/
#define CUVIS_MESU_PAN_KEY "pan"

/** name of the GPS data field, if available */
#define CUVIS_MESU_GPS_KEY "GPS_data"

/** name of the generate preview image, if available. The preview will be generated by the @ref cuvis_proc_cont_apply function*/
#define CUVIS_MESU_PREVIEW_KEY "preview"

/** @brief If this field is present, a dark was set while recording the measurement.
  * This is the dark that is implicitly loaded when a processing context is created
  * with the current measurement and used, if a dark is needed (unless overwritten by
  * @ref cuvis_proc_cont_set_reference )
  * The reference file should be located in ../Calibration/<reference-name>.cu3 or the
  * precise path defined by the string value of the data tag
  */
#define CUVIS_MESU_DARKREF_KEY "dark_ref"

/** @brief If this field is present, a white was set while recording the measurement.
  * This is the white that is implicitly loaded when a processing context is created
  * with the current measurement and used, if a dark is needed (unless overwritten by
  * @ref cuvis_proc_cont_set_reference )
  * The reference file should be located in ../Calibration/<reference-name>.cu3 or the
  * precise path defined by the string value of the data tag
  */
#define CUVIS_MESU_WHITEREF_KEY "white_ref"

/** @brief If this field is present, a white's dark was set while recording the measurement.
  * This is the white' dark that is implicitly loaded when a processing context is created
  * with the current measurement and used, if a dark is needed (unless overwritten by
  * @ref cuvis_proc_cont_set_reference )
  * The reference file should be located in ../Calibration/<reference-name>.cu3 or the
  * precise path defined by the string value of the data tag
  */
#define CUVIS_MESU_WHITEDARKREF_KEY "white_dark_ref"

/** see @ref CUVIS_MESU_FLAG_OVERILLUMINATED */
#define CUVIS_MESU_FLAG_OVERILLUMINATED_KEY "Flag_DataIsOverilluminated"

/** see @ref CUVIS_MESU_FLAG_POOR_REFERENCE */
#define CUVIS_MESU_FLAG_POOR_REFERENCE_KEY "Flag_DataUsesPoorReference"

/** see @ref CUVIS_MESU_FLAG_POOR_WHITE_BALANCING */
#define CUVIS_MESU_FLAG_POOR_WHITE_BALANCING_KEY "Flag_PoorWhiteBalancingData"

/** see @ref CUVIS_MESU_FLAG_DARK_INTTIME */
#define CUVIS_MESU_FLAG_DARK_INTTIME_KEY "Flag_IntegrationTimeMismatchDark"

/** see @ref CUVIS_MESU_FLAG_DARK_TEMP */
#define CUVIS_MESU_FLAG_DARK_TEMP_KEY "Flag_TemperatureMismatchDark"

/** see @ref CUVIS_MESU_FLAG_WHITE_INTTIME */
#define CUVIS_MESU_FLAG_WHITE_INTTIME_KEY "Flag_IntegrationTimeMismatchWhite"

/** see @ref CUVIS_MESU_FLAG_WHITE_TEMP */
#define CUVIS_MESU_FLAG_WHITE_TEMP_KEY "Flag_TemperatureMismatchWhite"

/** see @ref CUVIS_MESU_FLAG_WHITEDARK_INTTIME */
#define CUVIS_MESU_FLAG_WHITEDARK_INTTIME_KEY "Flag_IntegrationTimeMismatchWhiteDark"

/** see @ref CUVIS_MESU_FLAG_WHITEDARK_TEMP */
#define CUVIS_MESU_FLAG_WHITEDARK_TEMP_KEY "Flag_TemperatureMismatchWhiteDark"
/** @}*/

/** \addtogroup cuvis_info_layer The info layer
  *
  * The info layer can be retrieved with the function @ref cuvis_measurement_get_data_image
  * Though is appears to be an image and will also be exported and fragmented as an image
  * it is actually a set of flags. Each position of the a info-layer pixel represents a data
  * flag for a respective cube (or pan image).
  *
  * E.g. if a cube (@ref CUVIS_MESU_CUBE_KEY) has the size of 410x410x164 (W x H x Chn), the
  * respective info layer (@ref CUVIS_MESU_CUBE_INFO_KEY) will have a size of 410x410. The info_layer
  * value at position x,y contains the flags for the whole spectrum at position x,y in the cube.
  *
  * The same is true for the pan-chromatic image ((@ref CUVIS_MESU_CUBE_INFO_KEY) and @ref CUVIS_MESU_CUBE_INFO_KEY, respectively)
  *
  * The info layer pixel value is retrieved by binary operation.
  *
  * @note The info layer may not be available on all devices.
  *
  *Example:
  *
  * @code
  * // mesu is a measurement already loaded
  * // load the info channel to cube_info_layer_buffer
  * CUVIS_IMBUFFER cube_info_layer_buffer;
  * cuvis_measurement_get_data_image(mesu, CUVIS_MESU_CUBE_INFO_KEY, &cube_info_layer_buffer);
  * //now load pixel x=15, y=17' s flag information
  * int x = 15, y = 17;
  * uint16_t info_ptr = (const uint16_t*)(cube_info_layer_buffer.raw);
  * cube_info_layer_buffer pixel_info = IMBUFFER_GET(info_ptr, x, y, 0, imbuf);
  * //check if the pixel is ok
  * if (pixel_info == CUVIS_MESU_INFO_OK)
  *     printf("pixel 15|17 ok \n");
  * else
  * {
  *     // multiple flags can be set
  *     if ((pixel_info  & CUVIS_MESU_INFO_BAD_PIXEL) != 0)
  *         printf("pixel 15|17 is over-illuminated \n");
  *
  *     if ((pixel_info  & CUVIS_MESU_INFO_OVERILLUMINATED) != 0)
  *         printf("pixel 15|17 is a bad pixel \n");
  *     // ...
  * }
  * @endcode
  *  @{
  */

/** name of the info channel of its respective cube.*/
#define CUVIS_MESU_CUBE_INFO_KEY "cube_info_layer"

/** name of the info channel of its respective pan image.*/
#define CUVIS_MESU_PAN_INFO_KEY "pan_info_layer"

/** no flag set, only valid, if pixel value is equal 0 */
#define CUVIS_MESU_INFO_OK 0

/** one or more channels of the spectrum are over-exposed / the pan image is over-exposed at this position*/
#define CUVIS_MESU_INFO_OVERILLUMINATED 1

/** the pixel is marked bad, eg. a pixel of the respective spectrum is dead */
#define CUVIS_MESU_INFO_BAD_PIXEL 2

/** one or more channels of the spectrum of the white reference that was used to calculate this position was over-exposed*/
#define CUVIS_MESU_INFO_OVERILLUMINATED_REFERENCE 4

/** the meausurement was darker then the dark reference at this position (underflow) */
#define CUVIS_MESU_INFO_UNDERFLOW_MEASUREMENT_MIN_DARK 8

/** the white reference was darker then the dark reference at this position (underflow) */
#define CUVIS_MESU_INFO_UNDERFLOW_WHITE_MIN_DARK 16

/** the reflectance value exceeded the maximum value possible by the data format (i.e. the value reflectance reached or exceeded 655.35% (uint16 value of 65535) */
#define CUVIS_MESU_INFO_REFERENCE_CALC_OVERFLOW 32

/** the spectrum at this position is incomplete, e.g by a bad / too close distance calibration */
#define CUVIS_MESU_INFO_INCOMPLETE 64

/** @} */

//todo capabilites binary flags

/* ENUMERATIONS */

/** @brief return state of any SDK function */
enum cuvis_status_t
{
  /** the function encountered no problems */
  status_ok = 1,
  /** the failed for some reason. Call cuvis_get_last_error_msg for details */
  status_error = -1,
  /** a async function has not been started yet */
  status_deferred = -10,

  /** the async call was overwritten by another async call to the same internal values */
  status_overwritten = -11,

  /** obtaining a async function result has timed out. Call again later */
  status_timeout = -12,

  /** polling a measurement returned no result / frame was dropped */
  status_no_measurement = -20,

  /** retrieving a value is (currently) not possible */
  status_not_available = -30,

  /** processing the measurement with the worker failed, raw data is available */
  status_not_processed = -41,

  /** storing the measurement with the worker/exporter failed */
  status_not_stored = -42,

  /** obtaining the measurement's view with the worker failed, raw data is available */
  status_no_view = -43

};

/** the state of the hardware */
enum cuvis_hardware_state_t
{
  /** at least one required components is offline */
  hardware_state_offline = 0,
  /** all required components are online, at least one optional component is offline */
  hardware_state_partially_online = 1,
  /** all components are online */
  hardware_state_online = 2
};

/** @brief The available log levels. */
enum cuvis_loglevel_t
{
  /** only report error not recoverable */
  loglevel_fatal = 0,

  /** report errors and @ref loglevel_fatal messages */
  loglevel_error = 1,

  /** report warnings and @ref loglevel_error messages.  */
  loglevel_warning = 2,

  /** report status information and @ref loglevel_warning messages.  */
  loglevel_info = 3,

  /** report all messages, including debug messages  */
  loglevel_debug = 4,
};

/** @brief supported image buffer formats */
enum cuvis_imbuffer_format_t
{
  /** 8 bit, unsigned */
  imbuffer_format_uint8 = 1,

  /** 16 bit, unsigned */
  imbuffer_format_uint16 = 2,

  /** 32 bit, unsigned */
  imbuffer_format_uint32 = 3,

  /** IEEE 754 single-precision (32 bit) floating-point value (a.k.a float) */
  imbuffer_format_float = 4,
};

#define CUVIS_IMBUFFER struct cuvis_imbuffer_t



/** The session file item type */
enum cuvis_session_item_type_t
{
  /** all regular measurements, also list dropped frames */
  session_item_type_frames = 0,
  /** all regular measurements, excluding dropped frames (i.e. actual images) */
  session_item_type_frames_no_gaps = 1,
  /** all reference measurements */
  session_item_type_references = 2
};


/** @brief the data field's type */
enum cuvis_data_type_t
{
  /** the data type is unsupported or unknown by the SDK */
  data_type_unsupported = 0,

  /** data type is image, retrieve with @ref cuvis_measurement_get_data_image */
  data_type_image = 1,

  /** data type is gps, retrieve with @ref cuvis_measurement_get_data_gps */
  data_type_gps = 2,

  /** data type is string, retrieve with @ref cuvis_measurement_get_data_string */
  data_type_string = 3,

  /** data type is sensor info, retrieve with @ref cuvis_measurement_get_data_sensor_info */
  data_type_sensor_info = 4,
};

/** @brief The processing mode (a.k.a. capture mode) of a measurement. */
enum cuvis_processing_mode_t
{
  /** @brief processed as cube, but without reference

         The measurement is processed into a cube. Effects of
         sensor temperature, vignetting,
         missing flat-fielding, etc. are not
         corrected.

          */
  Cube_Raw = 0,

  /** @brief processed as cube, with dark subtract as reference.

         Subtracts the dark from the raw measurement.
         I_DS = I_RAW - I_DARK
          */
  Cube_DarkSubtract = 1,

  /** @brief processed as cube, with dark subtract and white as reference

           Calculates the reflectance as follows:

           I_REF = 10000(I_RAW - I_DARK) / (I_WHITE - I_WHITEDARK)

           Depending on the camera, I_WHITEDARK will be substituted
           I_DARK, is missing. Note the factor of 10000.
           A value of 100% corresponds to 10000 counts.

            */
  Cube_Reflectance = 2,

  /** @brief processed as cube, with spectral radiance calibration

             The spectral radiance calibration is camera-dependent.
             It's value is given in the units of W m^{-2} sr^{-1} um^{-1}

              */
  Cube_SpectralRadiance = 3,

  /** unprocessed (no cube), only preview image */
  Preview = 5
};

/** @brief The type of a reference */
enum cuvis_reference_type_t
{
  /** a dark reference for dark subtract/reflectance/sp. rad */
  Reference_Dark = 0,

  /** white reference measurement, brightness defined as 100% */
  Reference_White = 1,

  /** the dark corresponding to the white reference measurement*/
  Reference_WhiteDark = 2,

  /** spectral sprad measurement object (spectral fields) */
  Reference_SpRad = 3,

  /** spectral distance reference (spectral fields). If normal mesu.
         is used, measurement is calculated from it */
  Reference_Distance = 4
};

/** @brief Operation mode of a camera. */
enum cuvis_operation_mode_t
{
  /** software trigger, aka "single shot mode" or "software mode"*/
  OperationMode_Software = 1,
  /**triggered by internal clock, aka "video mode"*/
  OperationMode_Internal = 2,
  /** triggered by external trigger, aka "trigger mode"*/
  OperationMode_External = 3,
  /** undefiend (e.g. changing) */
  OperationMode_Undefined = 4
};

/** @brief the pan sharpening interpolation type for scaling up the cube before applying the pan image's weights */
enum cuvis_pan_sharpening_interpolation_type_t
{
  /// nearest neighbor interpolation
  pan_sharpening_interpolation_type_NearestNeighbor = 0,
  /// bilinear interpolation (recommended)
  pan_sharpening_interpolation_type_Linear = 1,
  /// bicubic interpolation
  pan_sharpening_interpolation_type_Cubic = 2,
  ///Lanczos (8x8)
  pan_sharpening_interpolation_type_Lanczos = 3
};

/** @brief the pan-sharpening algorithm for calculating the pan image's weights */
enum cuvis_pan_sharpening_algorithm_t
{
  /** Interpolate @ref CUVIS_PAN_SHAPRENING_INTERPOLATION_TYPE but no operation
       * is applied to apply the pan image information to the data. This mode is
       * recommended together with NearestNeighbor interpolation.
       */
  pan_sharpening_algorithm_Noop = 0,

  /** @brief cuvis macro pixel algorithm
      * @author Dr. Rene Heine
      *
      * Weights spectral "macro pixel" with local pan image gradient
      */
  pan_sharpening_algorithm_CubertMacroPixel = 1,

  /** @brief cuvis pan ratio algorithm
      * @author Arnd Brandes
      *
      * Relative pan-image brighness (white refernce and current image) is used as weight for specral image
      */
  pan_sharpening_algorithm_CubertPanRatio = 2,

  /** @brief cuvis pan overlay algorithm
      * @author Philip Manke
      *
      * Mode used viewing classifier results with the pan image as an overlay. ONLY works with images from viewer
      */
  pan_sharpening_algorithm_AlphablendPanOverlay = 3,
};

/** @brief the tiff compression options */
enum cuvis_tiff_compression_mode_t
{
  /** do not compress data */
  tiff_compression_mode_None = 0,

  /** compress LZW. */
  tiff_compression_mode_LZW = 1
};

/** @brief the tiff export format. */
enum cuvis_tiff_format_t
{
  /** Export each channel as separate files */
  tiff_format_Single = 0,

  /** Create a multi-channel tiff (recommended format) */
  tiff_format_MultiChannel = 1,

  /** Create a multi-page tiff, i.e. each channel is a "sub-image" within the tiff.  */
  tiff_format_MultiPage = 2,
};

/** image data types for view data */
enum cuvis_view_category_t
{
  /** data is process as an image for displaying. Pan-sharpening may have been applied. The bit depth is always 8 per channel*/
  view_category_image = 0,

  /** data contains calculation results. The format is always single precision floating point. */
  view_category_data = 1,
};

/** the component types */
enum cuvis_component_type_t
{
  /** the component is an image sensor (camera) */
  component_type_image_sensor = 0,
  /** the component is a non-camera, e.g. GPS */
  component_type_misc_sensor = 1,
};

/* TYPE DEFINITIONS */

#define CUVIS_STATUS enum cuvis_status_t
#define CUVIS_LOGLEVEL enum cuvis_loglevel_t
#define CUVIS_IMBUFFER_FORMAT enum cuvis_imbuffer_format_t
#define CUVIS_DATA_TYPE enum cuvis_data_type_t
#define CUVIS_PROCESSING_MODE enum cuvis_processing_mode_t
#define CUVIS_OPERATION_MODE enum cuvis_operation_mode_t
#define CUVIS_HARDWARE_STATE enum cuvis_hardware_state_t
#define CUVIS_REFERENCE_TYPE enum cuvis_reference_type_t
#define CUVIS_PAN_SHAPRENING_INTERPOLATION_TYPE enum cuvis_pan_sharpening_interpolation_type_t
#define CUVIS_PAN_SHAPRENING_ALGORITHM_TYPE enum cuvis_pan_sharpening_algorithm_t
#define CUVIS_TIFF_COMPRESSION_MODE enum cuvis_tiff_compression_mode_t
#define CUVIS_TIFF_FORMAT enum cuvis_tiff_format_t
#define CUVIS_VIEW_CATEGORY enum cuvis_view_category_t
#define CUVIS_COMPONENT_TYPE enum cuvis_component_type_t
#define CUVIS_SESSION_ITEM_TYPE enum cuvis_session_item_type_t
/*  DATA STRUCUTRES */

/** @brief image buffer data structure with meta-data
    *
    * The image buffer data structure holds a anonymous
    * raw data pointer, that can be interpreted to give
    * a meaningful data array with the help of the other
    * members:
    * The \ref format gives the information of the data type,
    * the \ref width, \ref length, and \ref channels give the
    * number of elements in the array.
    *
    * The \ref wavelength property is only set for hyperspectral cubes
    * but not for normal images. If it exists, it is an array with the number
    * of channels
    *
    * Example:
    * @code
    * // format = CUVIS_IMBUFFER_FORMAT_UINT16
    * // x in [0, width)
    * // y in [0,   height)
    * // chn in [0, channels)
    * unsigned index = (y * width + x) * channels + chn;
    * uint16_t value = ((uint16_t*) raw)[index];
    * unsigned lambda = cube.wavelength[chn];
    * @endcode
    *
    * see also: \ref IMBUFFER_GET
    */
struct cuvis_imbuffer_t
{
  /** the memory reference of the cube.
                 Valid as long as the parent element (e.g. measurement)
                 is valid and unchanged. */
  uint8_t const* raw;
  /** number of bytes per data element */
  uint32_t bytes;
  /**  total number of bytes in array */
  uint32_t length;
  /** width of buffer */
  uint32_t width;
  /** height of buffer */
  uint32_t height;

  /** number of channels */
  uint16_t channels;

  /** @brief the buffer format
      *
      * The buffer format defines what the member \ref raw can be casted into.
      */
  CUVIS_IMBUFFER_FORMAT format;

  /** @brief the wavelength vector
      *
      * If the \ref imbuffer is not a hyperspectral cube, the value will be nullptr
      * For cubes this is an array of length channels, the elements define the
      * cube's wavelength in nanometers.
      */
  uint32_t const* wavelength;
};

struct cuvis_sensor_info_t
{
  /** number of averages used*/
  uint32_t averages;

  /** the sensors's temperature while readout (0 if not applicable) */
  int32_t temperature;

  /** gain value while recording */
  double gain;

  /** the timestamp (UTC) of the image readout (senor's hardware clock )*/
  CUVIS_TIMESTAMP readout_time;
};

/** @brief The gps data structure */
struct cuvis_gps_t
{
  /** gps longitude in decimal degrees */
  double longitude;

  /** gps latitude in decimal degrees */
  double latitude;

  /** gps altitude in meters*/
  double altitude;

  /** the timestamp (UTC) while recoding the gps.*/
  CUVIS_TIMESTAMP time;
};

/** internal session_info info of acquisition context */
struct cuvis_session_info_t
{
  /** session_info name */
  CUVIS_CHAR name[CUVIS_MAXBUF];

  /** SessionFile number. Will be increased by stopping & starting recording */
  CUVIS_INT session_no;

  /** Sequence number. Increases with each recorded frame. Reset, if session_no changes */
  CUVIS_INT sequence_no;
};
#define CUVIS_SESSION_INFO struct cuvis_session_info_t

/** @brief The measurement meta structure */
struct cuvis_mesu_metadata_t
{
  /** The name of the measurement */
  CUVIS_CHAR name[CUVIS_MAXBUF];

  /** The output file path */
  CUVIS_CHAR path[CUVIS_MAXBUF];

  /** The User Comment linked to the measurement */
  CUVIS_CHAR comment[CUVIS_MAXBUF];

  /** The Capture Time of the Measurement */
  CUVIS_TIMESTAMP capture_time;

  /** The factory calibration date of the device */
  CUVIS_TIMESTAMP factory_calibration;

  /** The name of the device, which took the measurement */
  CUVIS_CHAR product_name[CUVIS_MAXBUF];

  /** The serial number of the device, which took the measurement */
  CUVIS_CHAR serial_number[CUVIS_MAXBUF];

  /** The Assembly Data of the device */
  CUVIS_CHAR assembly[CUVIS_MAXBUF];

  /** The integration time of the measurement (exposure time) in ms */
  double integration_time;

  /** Number of averaging taken */
  CUVIS_INT averages;

  /** Distance, the measurement was recorded in mm. If not provided, value is -1 */
  double distance;

  /** session_info name */
  CUVIS_CHAR session_info_name[CUVIS_MAXBUF];

  /** SessionFile number. Will be increased by stopping & starting recording */
  CUVIS_INT session_info_session_no;

  /** Sequence number. Increases with each recorded frame. Reset, if session_no changes */
  CUVIS_INT session_info_sequence_no;

  /** The actual Capture Mode of the cube */
  CUVIS_PROCESSING_MODE processing_mode;

  /** measurement flags */
  CUVIS_FLAGS measurement_flags;
};



/** @brief options for saving as cu3/cu3s files
  *
  * The cube exporter works asynchronically. For 
  *
  * ## offline saving to session file
  * When processing sesion files (@ref allow_session_file=true) offline, the option @ref allow_drop should be set to false. 
  * In this case measurements are added to the internal buffer until the size given by @ref hard_limit 
  * is reached.   
  * In this mode, the options @ref soft_limit and @ref max_buftime are ignroed.
  * 
  * ## online saving to session file
  * When recording sesion files (@ref allow_session_file=true) live, the options @ref allow_drop should be set to true. 
  *
  * When a new measurement is added to the cube exporter, the following strategy is applied:
  * 
  * 1. The internal buffer has a total limit of size @ref hard_limit. If the buffer is full, 
  * it will be dropped (end).
  * 
  * 2. If the buffer is not full, the @ref soft_limit is checed. If it is reachd, the ordering of the frame numbers is ignored 
  * and the measurement with the lowest sequence nubmer is stored to the disk directly. (This can mess up the order of the frames
  * set @ref soft_limit = @ref hard_limit to disable this behaviour)
  * 
  * 3. All meausurements in the internal buffer are checked: If they are held in the buffer for longer then the time given by 
  * @ref max_buftime, they are saved to disk directly. (This can mess up the order of the frames
  * set @ref max_buftime to a higher value allow for longer hold time intervals.)
  */
struct cuvis_save_args_t
{
  /** allow to split file to multiple files. 
    *
    * When exporting to a cu3s file (@ref allow_session_file=true) the allow_fragmentation flag controlles 
    * if all measurements (of the same session name) are written to one file like a single file (set to false) or 
    * if each measurement is saved to a separate cu3s file (set to true). The latter option generates substantial 
    * overhead.
    * 
    * When exporting to a (legacy) cu3 file (@ref allow_session_file=false), the fragmentation flag will lead
    * to multiple files exported: a <name>.cu3 file, followed by <name>_<postfix>.tiff files. These come as a tuple
    * and must be kept together, else the file will be corrupted. This export option is intended for legacy programs
    * that were deisnged to read raw data with the previous software verison 2.x. 
    * 
    */
  CUVIS_INT allow_fragmentation;

  /** allow to overwrite an existing file.  
    *
    * This option anables to allow to ovewrite files on the disk, if they exist. 
    *
    * @note When exporting to legacy format of version 2.x (@ref allow_session_file=false and @ref allow_fragmentation=true),
    * only the existance of the *.cu3 file is checked, existing *.tiff files are neither cleaned up nor checked if they exist
    * prior overwriting.
    */
  CUVIS_INT allow_overwrite;

  /** allow to drop files, if output buffers are full
    *
    * This options controlls the export behaviour. If internal write buffers are full, 
    * new measurements are either dropped or kept. 
    * 
    * The policy to drop measurements on full buffer (allow_drop=true) is recommended for online opration. The 
    * idea is to rather drop measurements and thus allow the acquisition to continue without slowing down. 
    * When this policy is set, the @ref soft_limit and the @ref max_buftime options are also used (see there). 
    * 
    * If new measurements are forced to be kept (allow_drop=true), the exporter will wait until the measurement can be written.
    * This polocy is recommended for batch-processing measurements (offline). The options @ref soft_limit and @ref max_buftime 
    * are ignored.
    * 
    * @note This option only applies, if @ref allow_session_file=true.
    * */
  CUVIS_INT allow_drop;

  /** save files of same session number to a single cu3s file. If @ref allow_fragmentation is set, cu3s fill be split by measurement. Default in Wrappers: True */
  CUVIS_INT allow_session_file;

  /** save additional info file.
    * 
    * The info file is written to the same path as the export files. 
    * It is a plain text file and consits of the a header showing the recoridng FPS and mode and 
    * a body, where each frame number from 0 till the last frame written is shown by their name. 
    * Missing frames are noted as "dropped".
    * 
    * @note The output of this file is not flushed until the exporter writes to a different file or is closed. Thus, it is not 
    * suited to be used as a way to monitor frame drops during live acquisiton.
    *
    * This option is ignored, when @ref allow_session_file is set to false.
    */
  CUVIS_INT allow_info_file;

  /** give the current operation mode. 
    *
    * Save the operation mode used while recording.
    * Only used if @ref allow_session is set.
    * */
  CUVIS_OPERATION_MODE operation_mode;

  /** the fps used in operation_mode video
    *
    * only used if @ref allow_session=true and @operation_mode=Internal. 
    * */
  double fps;

  /** Out-of-order frames are sorted within the cache, as long as the cache useage is below this limit. 
    *
    * The soft limit is only used if @ref allow_drop=true and @ref allow_session_file=true.
    *
    * The internal chache may hold up to @ref soft_limit number of frames that are out of sequence.
    *
    * For example: Let the the seqence number of the measurement written last be #14, and let the internal 
    * cache hold the frames  #16,#17,...#24 (9 images in chache) and let the soft limit be 10
    * If we assume the next frame to be #25, the 10 images in cache reached the soft limit, forcing
    * the first frame with the lowest nubmer (#16) to be written (#15 is makred as 'dropped'). 
    * If the next image actually is #15, this image is then written out of sequence, resulting in the
    * order #14, #16, #15. 
    * 
    * Theese are the states of the example avove.
    * 
    * > write to disk: #14
    * 
    * > cache: #16,#17,...#24 [soft limit: 10]
    * 
    * > insert: #25
    * 
    * > write to disk: #16
    * 
    * > cache: #17,...#24, #25 [soft limit: 10]
    * 
    * > insert: #15
    * 
    * > write to disk: #15
    * 
    * > cache: #17,...#24, #25 [soft limit: 10]
    * 
    * This behaviour is a compromise between keeping the seuqence in order and at the same time
    * not storing too many images if a frame was acutally dropped. 
    * Increase the soft_limit to a value same or grater the @ref hard_limit to disable this behaviour.
    */
  CUVIS_INT soft_limit;

  /** Maximum number of elements in output cache 
    *
    * The hard limit is only used if @ref allow_session_file=true.
    * 
    * The output cache has a maximum size of @ref hard_limit. If more measurements
    * are added, adding another measurment is not possible. 
    * Adding a measurement will lock the calling function if @ref allow_drop is set to false.
    * If @ref allow_drop is set to true, the added frame is directrly dropped and not stored.
    *
    * @note This behaviour also applies when using the exproter within a worker.
    * 
    */
  CUVIS_INT hard_limit;

  /** Any frame is forced to be written after this time (in ms), latest. 
    *
    * The maximum buffer time option is only used if @ref allow_drop=true and 
    * @ref allow_session_file=true.
    * 
    * The time a buffer is held in the exporter's cache is tracked. If the time given
    * by the max_buftime is exceeded, a measuremnt is written to disk. 
    *
    * This option also helps to guarantee a measurements to be serialized to a permanent
    * storage and avoid data loss upon power or abnormal program termination.
    * 
    * This option will overwrite the @ref soft_limit for this frame, if needed. 
    * 
    * */
  CUVIS_INT max_buftime;
};

/** @brief processing arguments */
struct cuvis_proc_args_t
{
  /** the processing mode to be used.
      *
      * use @ref cuvis_proc_cont_is_capable to check,
      * if the mode is currently possible of a specific measurement
      */
  CUVIS_PROCESSING_MODE processing_mode;

  /** allow to use different calibration (expert option)
      *
      * This options allows to process raw data with a different calibration.
      * this is, however, limited to the same hardware.
      *
      * If the hardware was mechanically changed, results may be poor or not usable
      * at all. Unless the accuracy of the result can be verified, this option is
      * not recommended.
      * */
  CUVIS_INT allow_recalib;
};

/** @brief general export settings */
struct cuvis_export_general_settings_t
{
  /** The export directory */
  CUVIS_CHAR export_dir[CUVIS_MAXBUF];

  /** The export channel selection  
      *
      * Use "all" or "full" for all available channels
      *
      * Use ranges for wavelength range start-end or start:end or start:step:end ;
      * All values in Nanometers.
      * Examples: 450:10:550 or 450-550
      */
  CUVIS_CHAR channel_selection[CUVIS_MAXBUF];

  /** multiply spectrum by fixed factor before exporting 
  *
  * This is most usefull for bitshifting the data - especially when the pan image is also added to the export.
  */
  double spectra_multiplier;

  /** amount of pan-sharpening
      *
      * The value is relative to the pan image size, give a value between 0 and 1 */
  double pan_scale;

  /** for pansharpening use this interpolation type to scale up the cube before adjusting the weights 
  *
  * As a first step to pan-sharpening the spectral data needs to be re-sanpled to the target resolution
  * This parameter determines the method for this resanpling. 
  */
  CUVIS_PAN_SHAPRENING_INTERPOLATION_TYPE pan_interpolation_type;

  /** method for calculating the weights */
  CUVIS_PAN_SHAPRENING_ALGORITHM_TYPE pan_algorithm;

  /** opacity for @ref pan_sharpening_algorithm_AlphablendPanOverlay, give a value between 0 and 1
    * a value of 1.0 represents usage of 100% pan image, 0 will be 100% view image
    */
  double blend_opacity;

  /** add pan to exported image. 
  *
  * If applicable, the pan image is scaled to target pan-sharpening resolution. 
  */
  CUVIS_INT add_pan;

  /** add full-resolution pan to exported image. 
  * 
  * If applicable, the image is added directly to the output.
  * else, the image is stored separately. 
  */
  CUVIS_INT add_fullscale_pan;

  /** Set exporter to "permisive mode" 
  * 
  * If set, errors will be skipped and alternative values assumed, wherever possible. 
  *
  * E.g., if @ref add_pan is selected but there is no panchromatic image avaialbe, the export is not possible. 
  * In permissive mode, however, the add_pan option is de-activated and an exprot without pan image is conducted
  * instead.
  * 
  * @note This mode may lead to unexpected behaviour and should be used with caution.
  */
  CUVIS_INT permissive;
};

/** @brief Additional settings for exporting to a userplugin view. See also \ref cuvis_export_general_settings_t */
struct cuvis_export_view_settings_t
{
  /** The userplugin xml string. See userplugin manual. */
  CUVIS_CHAR const* userplugin;
};

/** @brief Additional settings for exporting tiff. See also \ref cuvis_export_general_settings_t */
struct cuvis_export_tiff_settings_t
{
  /** the compression mode for tiff export */
  CUVIS_TIFF_COMPRESSION_MODE compression_mode;

  /** the tiff export mode / format */
  CUVIS_TIFF_FORMAT format;
};

/** @brief viewer settings */
struct cuvis_viewer_settings_t
{
  /** The userplugin xml string. See userplugin manual. */
  CUVIS_CHAR const* userplugin;

  /** amount of pan-sharpening
      *
      * The value is relative to the pan image size, give a value between 0 and 1 */
  double pan_scale;

  /** for pansharpening use this interpolation type to scale up the cube before adjusting the weights */
  CUVIS_PAN_SHAPRENING_INTERPOLATION_TYPE pan_interpolation_type;

  /** method for calculating the weights */
  CUVIS_PAN_SHAPRENING_ALGORITHM_TYPE pan_algorithm;

  /** also include parts that were not marked as "show" */
  CUVIS_INT complete;

  /** opacity for @ref pan_sharpening_algorithm_AlphablendPanOverlay, give a value between 0 and 1
    * a value of 1.0 represents usage of 100% pan image, 0 will be 100% view image
    */
  double blend_opacity;
};

/** @brief The view meta structure */
struct cuvis_view_data_t
{
  /** The id of the view*/
  CUVIS_CHAR id[CUVIS_MAXBUF];

  /** the type of view data*/
  CUVIS_VIEW_CATEGORY category;

  /** the actual data. View data is always 8 bit, i.e. imbuffer bytes = 1 */
  CUVIS_IMBUFFER data;

  /** 1 if dataset is intended for showing, 0 else */
  CUVIS_INT show;
};

/** Information about components */
struct cuvis_component_info_t
{
  /** type of the component */
  CUVIS_COMPONENT_TYPE type;

  /** the name that can be displayed human-readable */
  CUVIS_CHAR displayname[CUVIS_MAXBUF];

  /** the sensor's meta-informaiton */
  CUVIS_CHAR sensorinfo[CUVIS_MAXBUF];

  /** additional sensor informaiton */
  CUVIS_CHAR userfield[CUVIS_MAXBUF];

  /** additional sensor informaiton */
  CUVIS_CHAR pixelformat[CUVIS_MAXBUF];
};

#define CUVIS_EVENT_BASE_DATA struct cuvis_event_base_data_t
#define CUVIS_EVENT_ACQUISITION_DATA struct cuvis_event_acquisition_data_t
#define CUVIS_EVENT_PROCESSING_DATA struct cuvis_event_processing_event_t
#define CUVIS_EVENT_QUALITY_DATA struct cuvis_event_qualitiy_event_t
#define CUVIS_EVENT_COMPONENT_DATA struct cuvis_event_component_data_t

struct cuvis_event_base_data_t
{
  CUVIS_INT event_id;
};

struct cuvis_event_acquisition_data_t
{
  CUVIS_ACQ_CONT source;
};

struct cuvis_event_processing_event_t
{
  CUVIS_PROC_CONT source;
};

struct cuvis_event_qualitiy_event_t
{
  CUVIS_HANDLE source;
};

struct cuvis_event_component_data_t
{
  CUVIS_HANDLE compent_id;
};

/** settings for the worker */
struct cuvis_worker_settings_t
{
  /** @brief Number of threads.
    * 
    * give the number of worker threads to be used. If set to 0, the system's hardware concurrency is used (e.g 12 for a 6core/12 threads - CPU) 
    * */
  CUVIS_INT worker_count;

  /** internal poll interval in milliseconds. If set to 0, the internal default  (10ms) is used */
  CUVIS_INT poll_interval;
  /** If images are retrieved out of sequence, do not drop them (if set to 1).
      *
      * @note Typically, out-of sequence images occur, when the system can't keep up. You should reduce FPS or reduce disable processing.
      */
  CUVIS_INT keep_out_of_sequence;

  /** The number of measurements / views that the worker can store for retrieval in total.*/
  CUVIS_INT worker_queue_hard_limit;

  /** The number of measurements / views that the worker can store for retrieval before it will stop to accept new results.
    * Ideally the hard limit minus the worker count.
    */
  CUVIS_INT worker_queue_soft_limit;

  /** If set to 0, the worker is not allowed to drop results from its result queue, if set to 1, dropping is allowed.
    * This behaviour may be desired for video playback or similar tasks where data loss is acceptable in favor of processing speed.
    * Dropping frames should be disallowed for bulk reprocessing tasks.
    */
  CUVIS_INT can_drop;
};

/*  ADDITIONAL DEFINITIONS */
#define CUVIS_GPS struct cuvis_gps_t
#define CUVIS_MESU_METADATA struct cuvis_mesu_metadata_t
#define CUVIS_SAVE_ARGS struct cuvis_save_args_t
#define CUVIS_PROC_ARGS struct cuvis_proc_args_t
#define CUVIS_EXPORT_GENERAL_SETTINGS struct cuvis_export_general_settings_t
#define CUVIS_EXPORT_CUBE_SETTINGS struct cuvis_save_args_t
#define CUVIS_EXPORT_VIEW_SETTINGS struct cuvis_export_view_settings_t
#define CUVIS_EXPORT_TIFF_SETTINGS struct cuvis_export_tiff_settings_t
#define CUVIS_VIEWER_SETTINGS struct cuvis_viewer_settings_t
#define CUVIS_VIEW_DATA struct cuvis_view_data_t
#define CUVIS_COMPONENT_INFO struct cuvis_component_info_t
#define CUVIS_SENSOR_INFO struct cuvis_sensor_info_t
#define CUVIS_WORKER_SETTINGS struct cuvis_worker_settings_t

#ifndef MATLAB
typedef void(SDK_CCALL* log_callback)(const char* msg, CUVIS_INT level);
typedef void(SDK_CCALL* log_callback_localized)(const CUVIS_WCHAR* msg, CUVIS_INT level);
#endif

#ifndef MATLAB

  /* EVENT TYPEDEFS */
  /*enum cuvis_event_handler_t
{
  base_event,
  acquisition_event,
  processing_event,
  quality_event,
  component_event,
  /* TODO Add more eventhandler
}; */

  //                                        mmmmxxxxssss

  /*
  #define CUVIS_EVENT_ACQUISTION         0b000100000000
  #define CUVIS_EVENT_COMPONENT        0b000100010000
  #define CUVIS_EVENT_TRIGGER_SKIPPED  0b000100010001
  */

  #define CUVIS_EVENT_PROCESSING (2 << 8)

  #define CUVIS_EVENT_ACQUISTION (1 << 8)

  #define CUVIS_EVENT_COMPONENT (CUVIS_EVENT_ACQUISTION | (1 << 4))

  #define CUVIS_EVENT_TRIGGER_SKIPPED (CUVIS_EVENT_COMPONENT | 1)

  #define CUVIS_EVENT CUVIS_HANDLE

SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_event_get_acquisition_data(CUVIS_EVENT i_event, CUVIS_EVENT_ACQUISITION_DATA* o_p_acquisition_data);

/* EVENT CALLBACKS */

/** event callback type */
typedef void(SDK_CCALL* external_event_callback)(CUVIS_INT i_handler_id, CUVIS_EVENT i_event);

/** Register an event handler.
  * The event handler will be called on all events which satisfy the supplied event handler type. Returns an id for the event handler
  * to allow unregistering of the specific event handler
  * only valid during the runtime of the callback.
  *
  * @param[in] i_callback the event handler function callback
  * @param[in] i_type the type of the event handler which is registered
  * @param[out] o_p_handler_id a pointer where the handler id will be written to
  * */

SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_register_external_event_callback(external_event_callback i_callback, CUVIS_INT i_type, CUVIS_INT* o_p_handler_id);

/** Unregisters an event handler. Supply a valid handler id to specific the correct callback which is going to be unregistered */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_unregister_event_callback(CUVIS_INT i_handler_id);

#endif

/* FUNCTIONS */

/** Call this function for obtaining the last error message */
SDK_CAPI const CUVIS_CHAR* SDK_CCALL cuvis_get_last_error_msg(void);

/** Set the locale for localized error messages
*
* @param[in] i_locale_id set the locale id, e.g. "de" for german. See the "locale" directory for available translations.
*/
SDK_CAPI const CUVIS_STATUS SDK_CCALL cuvis_set_last_error_locale(CUVIS_CHAR const* id);

/** Call this function for obtaining the last localized error message
*
* @ref remember to set locale with @ref cuvis_set_last_error_locale first.
*/
SDK_CAPI const CUVIS_WCHAR* SDK_CCALL cuvis_get_last_error_msg_localized(void);

/** Set the internal log level. Log output will be redirected to cout
    *
    * If this function is not called, a failback logger is used, with loglevel "warning"
    * The failback logger is de-activated, when this function is called or when a callback is
    * registered for the log messages.
    * However, when this function is called, messages are logged to console, even when a callaback is
    * registered.
    * debug = 4, info = 3, warning = 2, error = 1, fatal = 0
    *
    * @params[in] level the log level to be set */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_set_log_level(CUVIS_INT level);

#ifndef MATLAB

/** Register an additional logger.
  * Only one classic callback will be set, multiple calls will overwrite the previous callback. The callback's message argument pointer is
  * only valid during the runtime of the callback.
  * The "classic" logger will output original messages, instead of it's respective translations. For localized (translated) messages, @see cuvis_reset_log_callback_localized.
  * @note The classical logger and localized logger can be used simultaneously.
  * @param[in] i_callback the function callback
  * @param[in] i_min_level the minimum level of the callback
  * */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_register_log_callback(log_callback i_callback, CUVIS_INT i_min_level);

/** Unregister the additional logger. This will not clear the localized logger */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_reset_log_callback();

/** Register an additional logger with localized language.
  * Only one callback will be set, multiple calls will overwrite the previous callback. The callback's message argument pointer is
  * only valid during the runtime of the callback.
  * @note The classical logger and localized logger can be used simultaneously.
  * @param[in] i_callback the function callback
  * @param[in] i_min_level the minimum level of the callback
  * @param[in] i_locale_id set the locale id, e.g. "de-DE.UTF8" for german. See the "locale" directory for available translations.
  * */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_register_log_callback_localized(log_callback_localized i_callback_localized, CUVIS_INT i_min_level, CUVIS_CHAR const* i_locale_id);

/** Unregister the additional localized logger. This will not clear the classic logger */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_reset_log_callback_localized();

#endif

/** The init function set the settings path.
    *
    * @params[in] i_settings_path The path to the settings directory. */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_init(CUVIS_CHAR const* i_settings_path);

/** @brief Get the SDK version
    *
    * @param[out] o_pVersion The output version string. The provided array must have the length of @ref CUVIS_MAXBUF
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_version(CUVIS_CHAR* o_pVersion);

/** @brief get the result of a async call.
    *
    * Get the return code (and error message, if applicable) of an async function, that has been called.
    * If result is not @ref status_ok use the @ref cuvis_get_last_error_msg function to get details.
    *
    * If the timeout is used (value above 0ms), @ref status_timeout or @ref status_deferred will be returned, if the function is not yet finished.
    * In that case, the asyncResult handle is still valid and can be used again.
    * If the result is @ref status_ok the function has finished. For both @ref status_ok and @ref status_error, the handle is now invalid.
    *
    * If the result is @ref status_overwritten the function's call was overwritten by another (similar) call. The actual value set by this
    * async function was not used, but the one of the other call. On this result, the handle is now invalid.
    *
    * @param[in,out] io_pAsyncResult the async handle obtained by calling a async function. If the call finished, the handle will be invalidated
    * @param[in] timeout_ms the timeout in ms. Give 0 to wait for ever.
    * @returns @ref status_ok if the async function finished successfully. @ref status_timeout or @ref status_deferred will be returned,
    * if the function is not yet finished. If the call failed, because it was overwritten it this function will return
    * @ref status_overwritten. If it failed for other reasons, the this function returns @ref status_error.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_call_get(CUVIS_ASYNC_CALL_RESULT* io_pAsyncResult, CUVIS_INT timeout_ms);

/** @brief Fortet an async measurement result without calling it */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_capture_free(CUVIS_ASYNC_CAPTURE_RESULT* io_pAsyncResult);

/** @brief Fortet an async call result without calling it */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_call_free(CUVIS_ASYNC_CALL_RESULT* io_pAsyncResult);

/** @brief checks the status of the async call object and returns it */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_call_status(CUVIS_ASYNC_CALL_RESULT i_pAsyncResult, CUVIS_STATUS* io_pStatusResult);

/** @brief checks the status of the async capture object and returns it */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_capture_status(CUVIS_ASYNC_CAPTURE_RESULT i_pAsyncResult, CUVIS_STATUS* io_pStatusResult);


/** @brief Capture a measurement
    *
    * This function is only available in operation mode "Software". The function executes a software trigger synchronously.
    *
    *
    * @param[in] i_acqCont the acquisition context
    * @param[out] o_pMesu the handle of the recorded image will be written to this variable
    * @param[in] timeout_ms the timeout in ms. Give 0 to wait for ever.
    * @retuns status_ok if the measurement was recorded. @ref status_timeout or @ref status_deferred is returned, if the capture was not completed (yet)
    * */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_capture(CUVIS_ACQ_CONT i_acqCont, CUVIS_MESU* o_pMesu, CUVIS_INT timeout_ms);

/** @brief Capture a measurement async
    *
    * This function is only available in operation mode "Software". The function executes a software trigger asynchronously.
    * The recorded measurement can be obtained by the function @ref cuvis_async_capture_get.
    *
    * If o_pAsyncResult is set to NULL, the measurement is added to the Acqusition Context's internal queue.
    * Retrieve it with @ref cuvis_acq_cont_get_next_measurement or via the worker (if used) @ref cuvis_worker_get_next_result
    *
    * @param[in] i_acqCont the acquisition context
    * @param[out] o_pAsyncResult the async capture handle will be written to this variable or NULL
    * @retuns status_ok if the async call could be executed.
    * */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_capture_async(CUVIS_ACQ_CONT i_acqCont, CUVIS_ASYNC_CAPTURE_RESULT* o_pAsyncResult);

/** @brief get the result of a async capture.
    *
    * Get the return code (and error message, if applicable) of an async capture, that has been called.
    * If result is not @ref status_ok use the @ref cuvis_get_last_error_msg function to get details.
    *
    * If the timeout is used (value above 0ms), @ref status_timeout or @ref status_deferred will be returned, if the function is not yet finished.
    * In that case, the asyncResult handle is still valid and can be used again.
    * If the result is @ref status_ok the function has finished. For both @ref status_ok and @ref status_error, the handle is now invalid.
    *
    * @param[in,out] io_pAsyncResult the async handle obtained by calling @ref capture_async. If the call finished, the handle will be invalidated
    * @param[in] timeout_ms the timeout in ms. Give 0 to wait for ever.
    * @param[out] o_pMesu write the measurement handle to this variable, if the call was successful. Else write CUVIS_HANDLE_NULL
    * @returns @ref status_ok if the async function finished successfully. @ref status_timeout or @ref status_deferred will be returned,
    * if the function is not yet finished. If it failed for other reasons, the this function returns @ref status_error.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_async_capture_get(CUVIS_ASYNC_CAPTURE_RESULT* io_pAsyncResult, CUVIS_INT timeout_ms, CUVIS_MESU* o_pMesu);

/** @brief Load a measurement from disk.
    *
    * The measurement is a cu3 file - and if fragmented some additional tiff files with a postfix, e.g. _cube.tiff
    * To load the file, all fragmented parts must be in the same directory. Fragmented files must not be renamed.
    *
    * @param[in] i_path the file path of the measurement
    * @param[out] o_pMesu the handle of the measurement.
    * @returns @ref status_ok, if the measurement could be loaded.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_load(const CUVIS_CHAR* i_path, CUVIS_MESU* o_pMesu);

/** create a deep copy of a measurement
  *
  * All operations on a measurement are performed on the same object. If different processing needs to be perfomed on a measurement
  * It should be deep-copied. The copied meausrement's name will be changed to end with "_copy"
  *
  * @param[in] i_mesu The measurement copy source.
  * @param[out] o_pMesu The copy will be linked to the handle given.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_deep_copy(CUVIS_MESU i_mesu, CUVIS_MESU* o_pMesu);

/** @brief Clears the cube from a measurement
*
* Clears the proceessing result, i. e. the cube, from the measurement. This returns the measurement the state before
* applying the processing. This can be usefull for reduced data usage.
*
* @param[in] i_mesu The measurement
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_clear_cube(CUVIS_PROC_CONT i_mesu);

/** @brief Clears an implicit reference measurement
*
* Implict measurements are created, when a measurement is processed with a processing context, where 
* explicit references are set. Then, these references are remebemred by the measurement. When changing
* the processing context, the references are implicitly available, still. Clearing them may be interesing
* if the references set are wrong/invalid or if disk space is a concearn.
*
* @param[in] i_mesu The measurement
* @param[in] i_type The type of the reference to be cleard
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_clear_implicit_reference(CUVIS_PROC_CONT i_mesu, CUVIS_REFERENCE_TYPE i_type);

/** @brief Load a session_info file from disk.
   *
   * The session_info file is a cu3s file and consists of binary cu3 measurement data. Call @ref cuvis_session_get_mesu
   * to obtain a single measurement frame. SessionFile files can be create with the Cube Exporter
   * (see @ref cuvis_exporter_create_cube)
   * @note Do not read a file currently opened for writing.
   *
   * @param[in] i_path the file path of the session_info file
   * @param[out] o_pSess the handle of the session_info file.
   * @returns @ref status_ok, if the measurement could be loaded.
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_load(const CUVIS_CHAR* i_path, CUVIS_SESSION_FILE* o_pSess);

/** @brief Release a session_info file handle
    *
    * Release a measurement by it's handle. The handle will be overwritten to @ref CUVIS_HANDLE_NULL
    * This will not affect any measurements on disk.
    * Measurements loaded from the session_info file remain valid.
    *
    * @param[in,out] o_pSess The handle to the measurement to be deleted
    * @returns @ref status_ok if the session_info file was released.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_free(CUVIS_SESSION_FILE* o_pSess);

/** @brief Load a measurement from the session_info file
  *
  * @param[in] i_sess the session_info file handle
  * @param[in] i_frameNo the frame no. Counting from 0, must be below value of @ref cuvis_session_get_size of it's respective @ref i_type
  * @param[in] i_type the type of listing (size depends on type)
  * @param[out] o_pMesu the handle of the measurement.
  * @returns @ref status_ok, if the measurement could be loaded.
  *          @ref status_no_measurement if the measurement was dropped.
  *          @ref status_error if the frame exeeds the number of frames.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_session_file_get_mesu(CUVIS_SESSION_FILE i_sess, CUVIS_INT i_frameNo, CUVIS_SESSION_ITEM_TYPE i_type, CUVIS_MESU* o_pMesu);

/** @brief Load a reference measurement from the session_info file
  *
  * @param[in] i_sess the session_info file handle
  * @param[in] i_frameNo the reference number. Counting from 0. If @ref i_type is not set, refers to the index of all references and must be below the value of @ref cuvis_session_get_size using type session_item_type_references. If @ref i_type is set, must be 0.
  * @param[in] i_type the type of reference measurement requested
  * @param[out] o_pMesu the handle of the measurement.
  * @returns @ref status_ok, if the reference could be loaded.
  *          @ref status_no_measurement if the reference does not exist.
  *          @ref status_error if the i_frameNo exeeds the number of references.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_session_file_get_reference_mesu(CUVIS_SESSION_FILE i_sess, CUVIS_INT i_frameNo, CUVIS_REFERENCE_TYPE i_type, CUVIS_MESU* o_pMesu);

/** @brief Get number of total frames of session_info file
  *
  * @param[in] i_sess the session_info file handle
  * @param[in] i_type the type of listing (size depends on type)
  * @param[out] o_pSize the size is written here.
  * @returns @ref status_ok if no error occurred.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_get_size(CUVIS_SESSION_FILE i_sess, CUVIS_SESSION_ITEM_TYPE i_type, CUVIS_INT* o_pSize);



/** @brief get a session_info file's FPS
   *
   * The session_info file meta-Information will be available only if the mode @cuvis_session_get_operation_mode returns "Internal"
   *
   * @param[in] i_sess the session_info file handle
   * @param[out] o_pFps the frames per second the session_info was recorded with.
   * @returns status_ok if fps could be retrieved, status_not_available if the session_info file has not FPS property set.
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_get_fps(CUVIS_SESSION_FILE i_sess, double* o_pFps);

/** @brief get a session_info file's hash
   *
   * @param[in] i_sess the session_info file handle
   * @param[out] o_pHash the hash of the sessionfile.
   * @returns status_ok if hash could be retrieved, status_not_available if the sessionfile has no hash property set.
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_get_hash(CUVIS_SESSION_FILE i_sess, CUVIS_CHAR* o_pHash);

/** @brief returns the operation mode the session_info file was recorded in
    *
    * The operation mode gives indication how the session_info file was recorded.
    *
    * @param[in] i_sess the session_info file handle
    * @param[out] o_pMode the operation mode of the session_info file.
    * @returns status_ok if no error occurred.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_session_file_get_operation_mode(CUVIS_SESSION_FILE i_sess, CUVIS_OPERATION_MODE* o_pMode);

/** @brief Get measurement from internal cache
   *
   * This function is only available in operation mode "Internal" or "External". The function obtains the image from the internal
   * memory, if available.
   *
   *
   * @param[in] i_acqCont the acquisition context
   * @param[out] o_pMesu the handle of the recorded image will be written to this variable.
   * @param[in] timeout_ms the timeout in ms. Give 0 to wait for ever.
   * @returns status_ok if the measurement was recorded. Returns status_no_measurement if no measurement was made available during the timeout time. If any error occurred status_error is returned.
   * */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_get_next_measurement(CUVIS_ACQ_CONT i_acqCont, CUVIS_MESU* o_pMesu, CUVIS_INT timeout_ms);

/** @brief check if any measurements are available in the buffer
    *
    * This function is only available in operation mode "Internal" or "External".
    *
    * @param[in] i_acqCont the acquisition context
    * @param[in] o_pHasNext value of 0 is written, if no measurements are available. value > 0, if a measurement is available.
    * @retuns status_ok if no error occurred. If any error occurred status_error is returned.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_has_next_measurement(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT* o_pHasNext);

/** @brief Save a measurement to disk
    *
    * Saves a single measurement to the disk in cu3 format.
    * The file name is given by the measurement's name (see \ref cuvis_measurement_set_name)
    *
    * @param[in] i_path The file directory
    * @param[in] i_mesu The handle of the measurement to be saved
    * @param[in] args The saving options
    * @returns @ref status_ok, if the measurement was save successfully.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_save(CUVIS_MESU const i_mesu, const CUVIS_CHAR* i_path, CUVIS_SAVE_ARGS args);

/** @brief Set the name of the measurement in memory
    *
    * By default, a newly aquired measurement has the name <SESSIONNAME>_<session_no>_<sequence_no> (see \ref CUVIS_SESSION_INFO).
    * This will also be the name of the file while saving it. This can be changed by this function.
    *
    * @param[in] i_name The new measurement's name
    * @returns @ref status_ok, if the measurement's name was set successfully.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_set_name(CUVIS_MESU const i_mesu, const CUVIS_CHAR* i_name);

/** @brief Set the comment of the measurement in memory
    *
    * 
    * @param[in] i_name The new measurement's comment
    * @returns @ref status_ok, if the measurement's name was set successfully.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_set_comment(CUVIS_MESU const i_mesu, const CUVIS_CHAR* i_comment);

/** @brief Release a measurement handle
    *
    * Release a measurement by it's handle. The handle will be overwritten to @ref CUVIS_HANDLE_NULL
    * This will not affect any measurements on disk.
    *
    * @param[in,out] io_pMesu The handle to the measurement to be deleted
    * @returns @ref status_ok if the measurement was released.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_free(CUVIS_MESU* io_pMesu);

/** @brief Obtain metadata from measurement
    *
    * The meta-data from the measurement contains information about
    * the measurement when it was recorded: when and how. Meta-Data
    * do not contain the actual recorded data.
    *
    * @param[in] i_mesu The measurement's handle
    * @param[out] o_pMetaData The meta structure to be filled
    * @returns @ref status_ok, if the meta-data could be loaded without errors
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_metadata(CUVIS_MESU i_mesu, CUVIS_MESU_METADATA* o_pMetaData);

/** @brief Get image data from measurement
    *
    * Return image data from a measurement. The image data is valid as long as
    * the measurement handle is not released and the measurement is not
    * re-processed.
    *
    * This function can only be called, if he data type is @ref data_type_image.
    * This can be checked by the function @ref cuvis_measurement_get_data_info.
    *
    * see also: @ref cuvis_reserved_keys
    *
    * @param[in] i_mesu The measurement handle
    * @param[in] i_key The data frame identification key (see @ref cuvis_measurement_get_data_info or @ref cuvis_reserved_keys)
    * @param[out] o_pBuf The image buffer to be filled
    * @returns @ref status_ok if the buffer could be filled with the image element.
    *          @ref status_unavailable if the requested data was empty, or the key could not be found
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_image(CUVIS_MESU i_mesu, const CUVIS_CHAR* i_key, CUVIS_IMBUFFER* o_pBuf);

/** @brief Get string data from measurement
    *
    * Return string data from a measurement.
    *
    * This function can only be called, if he data type is @ref data_type_string.
    * This can be checked by the function @ref cuvis_measurement_get_data_info.
    *
    * see also: @ref cuvis_reserved_keys
    *
    * @param[in] i_mesu The measurement handle
    * @param[in] i_key the data frame identification key (see @ref cuvis_measurement_get_data_info or @ref cuvis_reserved_keys)
    * @param[out] o_pValue The string buffer to be filled. The provided array must have the length of @ref CUVIS_MAXBUF
    * @returns @ref status_ok if the buffer could be filled with the string.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_string(CUVIS_MESU i_mesu, const CUVIS_CHAR* i_key, CUVIS_CHAR* o_pValue);

/** @brief Get image info data from measurement
    *
    * Return image data from a measurement. Tis
    *
    * This function can only be called, if he data type is @ref data_type_string.
    * This can be checked by the function @ref cuvis_measurement_get_data_info.
    *
    * see also: @ref cuvis_reserved_keys
    *
    * @param[in] i_mesu The measurement handle
    * @param[in] i_key the data frame identification key (see @ref cuvis_measurement_get_data_info or @ref cuvis_reserved_keys)
    * @param[out] o_pValue The string buffer to be filled. The provided array must have the length of @ref CUVIS_MAXBUF
    * @returns @ref status_ok if the buffer could be filled with the string.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_sensor_info(CUVIS_MESU i_mesu, const CUVIS_CHAR* i_key, CUVIS_SENSOR_INFO* o_pValue);

/** @brief Get GPS data from measurement
    *
    * Return gps data from a measurement.
    *
    * This function can only be called, if he data type is @ref data_type_gps.
    * This can be checked by the function @ref cuvis_measurement_get_data_info.
    *
    * see also: @ref cuvis_reserved_keys
    *
    * @param[in] i_mesu The measurement handle
    * @param[in] i_key the data frame identification key (see @ref cuvis_measurement_get_data_info or @ref cuvis_reserved_keys)
    * @param[out] o_pGps The gps buffer to be filled.
    * @returns @ref status_ok if the buffer could be filled with the gps data set.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_gps(CUVIS_MESU i_mesu, const CUVIS_CHAR* i_key, CUVIS_GPS* o_pGps);

/** @brief get meta-information of a data element
    *
    * Retrieve the meta-informations of a data element identified by it's positional number.
    * A measurement has N data elements (obtain N with the functions @ref cuvis_measurement_get_data_count)
    * Thus, the meta-data of element 0 to N-1 can be obtained.
    * The @ref o_pType defined the data type: If it is @ref data_type_image, retrieve it
    * with @ref cuvis_measurement_get_data_image.
    *
    * If it is data type is @ref data_type_gps, retrieve it with @ref cuvis_measurement_get_data_gps.
    * If it is @ref data_type_string, retrieve with @ref cuvis_measurement_get_data_string
    * If it is @ref data_type_unsupported, the data cannot be retrieved.
    *
    * To retrieve the data, you will require the @ref o_pKey wich you can obtain by using this function.
    * The key is the name of the data channel.
    *
    * Some keys are reserved, see @ref cuvis_reserved_keys
    *
    * @param[in] i_mesu The measurement handle
    * @param[out] o_pKey Output the data key
    * @param[out] o_pType The data type
    * @param[in] i_id The number of the data element
    * @returns @ref status_ok if the data information could be obtained
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_info(CUVIS_MESU i_mesu, CUVIS_CHAR* o_pKey, CUVIS_DATA_TYPE* o_pType, CUVIS_INT i_id);

/** @brief Retrieve the number of data elements
    *
    * @param[in] i_mesu The measurement handle
    * @param[out] o_pCount The number of data elements
    * @returns @ref status_ok if the data element count could be retrieved
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_data_count(CUVIS_MESU i_mesu, CUVIS_INT* o_pCount);

/** @brief Create a calibration from factory path
    *
    * The calibration is created from a factory path, containing the license and calibration
    * file "init.daq" as well as further calibration files (e.g. SpRad.cu3).
    *
    * The calibration is lazy-loading, i.e. the AcquisitionContext and the
    * ProcessingContext will only be initialized, when explicitly called.
    *
    * @note do not load multiple calibration instances of the same camera
    *
    * @param[in] i_factoryDir The path to the factory directory
    * @param[in] o_pCalibration the handle of the calibration
    * @returns @ref status_ok if the calibration could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_calib_create_from_path(const CUVIS_CHAR* i_factoryDir, CUVIS_CALIB* o_pCalibration);

/** @brief Create a calibration from session file
    *
    * Create a calibration from an existion session file.
    *
    * The calibration is lazy-loading, i.e. the AcquisitionContext and the
    * ProcessingContext will only be initialized, when explicitly called.
    * 
    * When you create a processing context from the calibration cerated with
    * this function, you won't have the references from the session file set.
    * Use @ref cuvis_proc_cont_create_from_session_file to load a processing context
    * where the referenecs are taken from the session file.
    *
    * @note do not load multiple calibration instances of the same camera
    *
    * @param[in] i_sess The session file
    * @param[in] o_pCalibration the handle of the calibration
    * @returns @ref status_ok if the calibration could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_calib_create_from_session_file(const CUVIS_SESSION_FILE i_sess, CUVIS_CALIB* o_pCalibration);


/** @brief Clear a loaded calibration by it's handle
    *
    * The internal memory is freed.
    *
    * @param[in,out] io_pCalibration The handle of the calibration. The handle
    * number will be invalidated.
    * @returns @ref status_ok if the calibration could be released
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_calib_free(CUVIS_CALIB* io_pCalibration);

/** @brief Load a acquisition context from a given calibration
    *
    * Load the acquisition context from the calibration. This will load the hardware and initialize it.
    * Do not load multiple instances of the came calibration / camera.
    *
    * @param[in] i_calib The calibration instance the processing context will be loaded from
    * @param[out] o_pAcqCont The handle of the acquisition context.
    * @returns @ref status_ok if the acquisition context could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_create_from_calib(CUVIS_CALIB i_calib, CUVIS_ACQ_CONT* o_pAcqCont);

/** @brief Load a acquisition context from a given session_file
    *
    * The acquisition context from the embedded acquisition context of the session_info file.
    *
    * @param[in] i_sess The session_file the processing context will be loaded from
    * @param[out] o_pAcqCont The handle of the acquisition context.
    * @returns @ref status_ok if the acquisition context could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_create_from_session_file(CUVIS_SESSION_FILE i_sess, CUVIS_INT i_simulate, CUVIS_ACQ_CONT* o_pAcqCont);

/** @brief get the online state of the hardware
  *
  * Hardware can be used, when at least it's required components are online.
  * @param[in] i_acqCont the acquisition context
  * @param[out] o_pState the state will be written here
  * @returns the state of the camera
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_get_state(CUVIS_ACQ_CONT i_acqCont, CUVIS_HARDWARE_STATE* o_pState);

/** @brief get the acquisition session_info
  *
  * Get the acquisition session_info settings. Also use this function to get the current sequence number.
  * @param[in] i_acqCont the acquisition context
  * @param[out] o_pSessionInfo the state will be written here
  * @returns status_ok, if no internal error occurred.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_get_session_info(CUVIS_ACQ_CONT i_acqCont, CUVIS_SESSION_INFO* o_pSessionInfo);

/** @brief set the acquisition session_info
  *
  * Set the acquisition session_info settings.
  * @param[in] i_acqCont the acquisition context
  * @param[out] i_pSessionInfo the session_info details to be set
  * @returns status_ok, if no internal error occurred.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_set_session_info(CUVIS_ACQ_CONT i_acqCont, CUVIS_SESSION_INFO const* i_pSessionInfo);

/** @brief set the receive queue buffer size
  *
  * Set the amounts of measurements that will be stored internally, ready for retrieval. Default=100.
  * @param[in] i_acqCont the acquisition context
  * @param[in] i_size the new queue size
  * @returns status_ok if the new queue size could be set.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_queue_size_set(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_size);

/** @brief Clear a loaded acquisition context by it's handle
    *
    * The internal memory is freed.
    *
    * @param[in,out] io_pAcqCont The handle of the processing context. The handle
    * number will be invalidated.
    * @returns @ref status_ok if the acquisition context could be released
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_free(CUVIS_ACQ_CONT* io_pAcqCont);

/** @brief Get components general info
  *
  * Return general component information about a component build into the acquisition hardware. This helps
  * identifying the correct component for settings specific component settings (e.g. gain)
  *
  * @param[in] i_acq_Cont the acquisition context
  * @param[in] i_id the device id (value between 0 and below @ref cuvis_acq_cont_get_component_count)
  * @param[out] o_pCompInfo the component info to be filled
  * @returns cuvis_ok if the info fields could be filled.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_get_component_info(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_id, CUVIS_COMPONENT_INFO* o_pCompInfo);

/** @brief Get the number of components
  *
  * The acquisition hardware is build from one or more components. Get the component count.
  * @param[in] i_acq_Cont the acquisition context
  * @param[out] o_pCount the number of components is written here
  * @returns cuvis_ok if the number of components could be set
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_get_component_count(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT* o_pCount);

/** @brief Load a processing context from a given calibration
    *
    *Load the processing context from the calibration.
    *
    *@param[in] i_calib The calibration instance the processing context will be loaded from
    *@param[out] o_pProcCont The handle of the processing context.
    *@returns @ref status_ok if the processing context could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_create_from_calib(CUVIS_CALIB i_calib, CUVIS_PROC_CONT* o_pProcCont);

/** @brief Load a processing context from a given measurement
    *
    * The processing context is loaded from the CALIBRATION directory, relative to
    * the measurement given ( ../Calibration/* ) . This directory is present in the normal camera operation
    * / recording, but the reference might get lost, if you manually move the
    * measurements. In that case, this function will fail.
    *
    * @param[in] i_mesu The measurement with a valid reference to the processing context
    * @param[out] o_pProcCont The handle of the processing context.
    * @returns @ref status_ok if the processing context could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_create_from_mesu(CUVIS_MESU i_mesu, CUVIS_PROC_CONT* o_pProcCont);

/** @brief Load a processing context from a given session_file
    *
    * The processing context from the embedded processing context of the session_info file.
    *
    * @param[in] i_sess The session_file with a valid reference to the processing context
    * @param[out] o_pProcCont The handle of the processing context.
    * @returns @ref status_ok if the processing context could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_create_from_session_file(CUVIS_SESSION_FILE i_sess, CUVIS_PROC_CONT* o_pProcCont);

/** @brief get a specific reference from the processing context
    *
    * The processing context can hold explicit references (e.g. a dark),
    * see @ref cuvis_proc_cont_set_reference. These reference can be obtained
    * by this functions
    *
    * @note Implicit references given by a measurement are not returned. If they are available can only be
    * checked indirectly by the @ref cuvis_proc_cont_is_capable or by checking for the measurement's data keys
    * @ref CUVIS_MESU_DARKREF_KEY, @ref CUVIS_MESU_WHITEREF_KEY and @ref CUVIS_MESU_WHITEDARKREF_KEY
    *
    * @param[in] i_procCont The handle of the processing context
    * @param[out] o_pMesu The reference measurement's handle
    * @param[in] i_type The type of the measurement to be retrieved.
    * @returns @ref status_ok if the reference measurement is available and could be loaded
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_get_reference(CUVIS_PROC_CONT i_procCont, CUVIS_MESU* o_pMesu, CUVIS_REFERENCE_TYPE i_type);

/** @brief Set a reference measurement
    *
    * The available processing modes (@ref cuvis_processing_mode_t) require certain references to be set.
    * When a measurement is recorded with references in place, these references are available per measurement implicitly.
    * However, if you want to process measurements with different references, or if the measurement lacks a reference,
    * they can be set with this function. 
    * 
    * @code
    * CUVIS_MESU mesu;
    * cuvis_measurement_load("mesu.cu3",&mesu);
    * //contains implicit Reference_Dark
    *
    * CUVIS_PROC_CONT pc;
    * cuvis_proc_cont_create_from_mesu(mesu,&pc); //will implicitly load Reference_Dark
    *
    * CUVIS_MESU white;
    * cuvis_measurement_load("white.cu3",&white);
    *
    * cuvis_proc_cont_set_reference(pc, white, Reference_White);
    *
    * //Cube_Reflectance requires Reference_Dark and Reference_White
    * cuvis_proc_cont_apply(pc,mesu,{Cube_Reflectance});
    * @endcode
    * @note The reference explicitly set by this function has priority over the implicit measurement.
    *
    * @param[in] i_procCont The handle of the processing context
    * @param[in] i_mesu The measurement to be used as explicit reference
    * @param[in] i_type The type of the reference
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_set_reference(CUVIS_PROC_CONT i_procCont, CUVIS_MESU i_mesu, CUVIS_REFERENCE_TYPE i_type);

/** @brief Clears a reference measurement
*
* Clears a reference explicitly set by @ref cuvis_proc_cont_set_reference
*
* @param[in] i_procCont The handle of the processing context
* @param[in] i_type The type of the reference
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_clear_reference(CUVIS_PROC_CONT i_procCont, CUVIS_REFERENCE_TYPE i_type);

/** @brief Set the operating distance by value
    *
    * Some cameras require a distance reference (calibration). This is usually obtained from a measurement at
    * that distance. However, if the distance is known, it can be set manually.
    *
    * @note Some OEM-Cameras or older models do not support this.
    * @note Internally, a measurement is created. It can be obtained by @ref cuvis_proc_cont_get_reference.
    *
    * @param[in] i_procCont The handle of the processing context
    * @param[in] i_distanceMM The distance in millimeters.
    * @returns @ref status_ok if the distance could be set
    * */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_calc_distance(CUVIS_PROC_CONT i_procCont, double i_distanceMM);


/** @brief Check if an explicit reference was set
    *
    * @param[in] i_procCont The handle of the processing context
    * @param[in] i_type The reference type
    * @param[out] o_pHasReference true, if reference is explicitly set. false, otherwise
    * @return @ref status_ok if no error occurred.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_has_reference(CUVIS_PROC_CONT i_procCont, CUVIS_REFERENCE_TYPE i_type, CUVIS_INT* o_pHasReference);

/** @brief Check if a processing mode is possible for a measurement
    *
    * Depending on the measurement, it's intrinsic references, the processing
    * context's explicit references and the internal camera calibration itself
    * the availability of a mode varies.
    *
    * Use this function, to check whether a specific mode is explicitly possible for
    * a measurement.
    *
    * @param[in] i_procCont The handle of the processing context
    * @param[in] i_mesu The measurement to be checked
    * @param[in] i_args The processing options to be checked
    * @param[out] o_pIsCapable true, if mode is possible. false, otherwise
    * @return @ref status_ok if no error occurred.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_is_capable(CUVIS_PROC_CONT i_procCont, CUVIS_MESU i_mesu, CUVIS_PROC_ARGS args, CUVIS_INT* o_pIsCapable);

/** @brief (Re-)Process a measurement
   *
   * Process a measurement according to the current settings of the processing context.
   * Those get set via @ref cuvis_proc_set_proc_args
   * The availability of the modes depends, use @ref cuvis_proc_cont_is_capable to check
   * if the processing is possible.
   *
   * In short:
   * @ref Cube_Raw does not require references (@ref Reference_Distance is optional)
   *
   * @ref Cube_DarkSubtract requires @ref Reference_Dark (and @ref Reference_Distance is optional)
   *
   * @ref Cube_Reflectance requires @ref Reference_Dark and @ref Reference_White reference (and @ref Reference_Distance
   * is optional), the @ref Reference_WhiteDark is strongly recommended if using different integration times.
   *
   * @ref Cube_SpectralRadiance depends on the camera model: All cameras require @ref Reference_SpRad. The Fireflye requires: @ref Reference_Dark, @ref Reference_White, the Ultris series requires only @ref Reference_Dark.
   *
   * @param[in] i_procCont The handle of the processing context
   * @param[in] i_mesu The measurement to be processed
   * @return @ref status_ok if measurement was processed.
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_apply(CUVIS_PROC_CONT i_procCont, CUVIS_MESU i_mesu);

/** @brief Sets the processing arguments for a processing contex
   *
   * For processing a measurement see @ref cuvis_proc_cont_apply
   *
   * @param[in] i_procCont The handle of the processing context
   * @param[in] i_processingMode The processing mode to be checked
   * @return @ref status_ok if measurement was processed.
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_set_args(CUVIS_PROC_CONT i_procCont, CUVIS_PROC_ARGS i_args);

/** @brief Clear a loaded processing context by it's handle
    *
    * The internal memory is freed.
    * @param[in,out] io_pProcCont The handle of the processing context. The handle
    * number will be invalidated.
    * @return @ref status_ok if processing context could be freed.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_free(CUVIS_PROC_CONT* io_pProcCont);

/** @brief Create a cube exporter
   *
   * @params[out] o_pExporter The handle of the exporter
   * @params[in] generalSettings General export settings
   * @params[in] formatSettings Additional Cube export settings
   * @returns @ref status_ok if the exporter was created successfully
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_exporter_create_cube(CUVIS_EXPORTER* o_pExporter, CUVIS_EXPORT_GENERAL_SETTINGS generalSettings, CUVIS_EXPORT_CUBE_SETTINGS formatSettings);

/** @brief Create a tiff exporter
   *
   * @params[out] o_pExporter The handle of the exporter
   * @params[in] generalSettings General export settings
   * @params[in] formatSettings Additional TIF export settings
   * @returns @ref status_ok if the exporter was created successfully
   */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_exporter_create_tiff(CUVIS_EXPORTER* o_pExporter, CUVIS_EXPORT_GENERAL_SETTINGS generalSettings, CUVIS_EXPORT_TIFF_SETTINGS formatSettings);

/** @brief Create a ENVI exporter
  *
  * @params[out] o_pExporter The handle of the exporter
  * @params[in] generalSettings General export settings
  * @returns @ref status_ok if the exporter was created successfully
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_exporter_create_envi(CUVIS_EXPORTER* o_pExporter, CUVIS_EXPORT_GENERAL_SETTINGS generalSettings);

/** @brief Create a VIEW exporter
    *
    * Not to be confused with the VIEWER. The view exporter saves views to disk.
    *
    * @params[out] o_pExporter The handle of the exporter
    * @params[in] generalSettings General export settings
    * @params[in] formatSettings Additional view export settings
    * @returns @ref status_ok if the exporter was created successfully
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL
    cuvis_exporter_create_view(CUVIS_EXPORTER* o_pExporter, CUVIS_EXPORT_GENERAL_SETTINGS generalSettings, CUVIS_EXPORT_VIEW_SETTINGS formatSettings);

/** @brief Export a measurement with an exporter
    *
    * @param[in] i_exporter The exporter
    * @param[in] i_mesu the measurement
    * @returns @ref status_ok if the measurement was exported successfully. @ref status_not_stored if the measurement could not be stored.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_exporter_apply(CUVIS_EXPORTER i_exporter, CUVIS_MESU i_mesu);


SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_exporter_get_queue_used(CUVIS_EXPORTER i_exporter, CUVIS_INT* o_pQueueUsed);

/** @brief Release an exporter
    *
    * @params[in,out] io_pExporter Exporter to be released. If successfully, handle will be invalidated
    * @returns @ref status_ok if the exporter was cleared.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_exporter_free(CUVIS_EXPORTER* io_pExporter);

/** @brief Create a viewer
    *
    * Not to be confused with the view exporter. The viewer returns the view in the memory
    *
    * @params[out] o_pViewer The handle of the viewer
    * @params[in] viewerSettings view settings
    * @returns @ref status_ok if the exporter was created successfully
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_viewer_create(CUVIS_VIEWER* o_pViewer, CUVIS_VIEWER_SETTINGS viewerSettings);

/** @brief Generate a view from a measurement
    *
    * The view is processed from a measurement by the viewer. The resulting view handle can be accessed by the
    * @ref cuvis_view_get_data_count to get number of elements,  @ref cuvis_view_get_data to get a single date element
    * and @ref cuvis_view_free to release the view (this must always be called)
    *
    * @param[in] i_viewer The viewer
    * @param[in] i_mesu the measurement
    * @param[out] o_pView the resulting view handle.
    * @returns @ref status_ok if the measurement was processed successfully.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_viewer_apply(CUVIS_VIEWER i_viewer, CUVIS_MESU i_mesu, CUVIS_VIEW* o_pView);

/** @brief Release a viewer
    *
    * @params[in,out] io_pViewer Viewer to be released. If successfully, handle will be invalidated
    * @returns @ref status_ok if the exporter was cleared.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_viewer_free(CUVIS_VIEWER* io_pViewer);

/** @brief retrieves the number of view data elements
  * @param[in] the view handle
  * @param[out] o_pCount The number of elements
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_view_get_data_count(CUVIS_MESU i_view, CUVIS_INT* o_pCount);

/** @brief Obtain data from view
    *
    * The data contains the actual view
    *
    * @param[in] i_view The view handle
    * @param[in] i_index The element number
    * @param[out] o_pData The actual view data
    * @returns @ref status_ok, if the meta-data could be loaded without errors
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_view_get_data(CUVIS_MESU i_view, CUVIS_INT i_index, CUVIS_VIEW_DATA* o_pData);

/** @brief Release a view
    *
    * @params[in,out] io_pView View to be released. If successfully, handle will be invalidated
    * @returns @ref status_ok if the exporter was cleared.
    */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_view_free(CUVIS_VIEWER* io_pView); //VIEWER or VIEW???

/*  MISC. */

/** @brief Get the capabilites of a given mode
*
* Use this function to evaluate which functions are available for a camera calibration.
* @param[im] i_calibration The calibration
* @param[in] i_mode The mode to check the capabiliets
* @param[out] o_pCapabilities write the capabilites here. See CUVIS_MODE_CAPABILITIES_x flags.
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_calib_get_capabilities(CUVIS_CALIB i_calibration, CUVIS_OPERATION_MODE i_mode, CUVIS_INT* o_pCapabilities);

/** @brief Get the capabilites of the measurement which were present in the calibration during capture.
*    This doesn't indicate which capabilities are currently available for the measurement.
*    See @ref cuvis_proc_cont_is_capable
*
* Use this function to evaluate which functions are available for a given measurement.
* @param[im] i_calibration The measurement
* @param[out] o_pCapabilities write the capabilites here. See CUVIS_MODE_CAPABILITIES_x flags.
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_capabilities(CUVIS_MESU i_mesu, CUVIS_INT* o_pCapabilities);

/** @brief Get the unique calibration id of a measurement
* 
* The id unique to a calibration is stored into everything created from it, as such a measurement also contains this id.
* 
* @param[in] i_mesu the measurement
* @param[out] o_pCalibId the output string
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_measurement_get_calib_id(CUVIS_MESU i_mesu, CUVIS_CHAR* o_pCalibId);


/** @brief Get the unique id of a calibration 
* 
* @param[in] i_mesu the measurement
* @param[out] o_pCalibId the output string
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_calib_get_id(CUVIS_CALIB i_calib, CUVIS_CHAR* o_pCalibId);

/** @brief Get the unique calibration id of a processing context
* 
* The id unique to a calibration is stored into everything created from it, as such a processing context also contains this id.
* 
* @param[in] i_procCont the processing context
* @param[out] o_pCalibId the output string
*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_proc_cont_get_calib_id(CUVIS_PROC_CONT i_procCont, CUVIS_CHAR* o_pCalibId);

/** @brief Create a Worker
  *
  * The encapsulates the functions of the Acquisiton Context, Processing Context, Exporter, and Viewer into a single
  * container and manages the communications between these.
  * It also enables multi-threaded operation
  * @note The set functions need to be called in order for the worker to be enabled.
  *
  * @param[out] o_pWorker The worker handle to be created
  * @param[in] worker_settings The worker configuration
  **/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_create(CUVIS_WORKER* o_pWorker, CUVIS_WORKER_SETTINGS worker_settings);

/** @brief release a worker */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_free(CUVIS_WORKER* io_pWorker);

/** @brief set the acquistion context for the worker. Give CUVIS_HANDLE_NULL to clear*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_acq_cont(CUVIS_WORKER i_worker, CUVIS_ACQ_CONT i_acq_cont);
/** @brief set the processing context for the worker. Give CUVIS_HANDLE_NULL to clear*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_proc_cont(CUVIS_WORKER i_worker, CUVIS_PROC_CONT i_proc_cont);
/** @brief set the exporter for the worker. Give CUVIS_HANDLE_NULL to clear */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_exporter(CUVIS_WORKER i_worker, CUVIS_EXPORTER i_exporter);
/** @brief set the viewer for the worker. Give CUVIS_HANDLE_NULL to clear */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_viewer(CUVIS_WORKER i_worker, CUVIS_VIEWER i_viewer);
/** @brief set a session file for the worker to process (read access only). Give CUVIS_HANDLE_NULL to clear.
  * Set parameter SkipDroppedFrames to 1 to skip any dropped frames contained in the session - 0 will insert empty frames.
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_session_file(CUVIS_WORKER i_worker, CUVIS_SESSION_FILE i_session_file, CUVIS_INT i_SkipDroppedFrames);
/** @brief Push a mesurement into the worker to process. Worker must have neither a session file nor an acquisition context. */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_ingest_mesu(CUVIS_WORKER i_worker, CUVIS_MESU i_mesu);
/** @brief Query the number of frames the worker has already read from a session file
 * and the total number of frames in the session. The worker automatically clears the session file upon reading the last frame.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_query_session_progress(CUVIS_WORKER i_worker, CUVIS_INT* o_frames_read, CUVIS_INT* o_frames_total);

/** @brief Get the next result in order 
  *
  * The measurement will be readyly recorded, processed (if set), stored (if set) and have a view (if set).
  * 
  * @param[in] i_worker The worker handle
  * @param[out] o_pMesu The recorded measurement or NULL if recording failed
  * @param[out] o_pView The view, if calculated sucessfully, else NULL
  * @param[in] i_Timeout_ms The number of milliseconds to wait for a result. -1 to wait indefinitely
  * @returns @ref status_ok or on error: @ref status_error, @ref status_not_processed, @ref status_not_stored, or @ref status_no_view, or @ref status_not_available
  */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_get_next_result(CUVIS_WORKER i_worker, CUVIS_MESU* o_pMesu, CUVIS_VIEW* o_pView, CUVIS_INT i_Timeout_ms);

/** @brief Check, if a new worker result is available */
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_has_next_result(CUVIS_WORKER i_worker, CUVIS_INT* o_pHasNext);

/** @brief Query the number of frames the worker has already read from a session file
 * and the total number of frames in the session. The worker automatically clears the session file upon reading the last frame.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_get_queue_limits(CUVIS_WORKER i_worker, CUVIS_INT* o_pHardLimit, CUVIS_INT* o_pSoftLimit);

/** @brief Query the number of items currently in the result queue.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_get_queue_used(CUVIS_WORKER i_worker, CUVIS_INT* o_pQueueUsed);

/** @brief Set the result queue limits: hard ^= queue size, soft ^= worker stops accepting mesu inputs.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_queue_limits(CUVIS_WORKER i_worker, CUVIS_INT i_HardLimit, CUVIS_INT i_SoftLimit);

/** @brief Set whether the worker can drop results when the result queue is full.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_set_drop_behavior(CUVIS_WORKER i_worker, CUVIS_INT i_CanDrop);

/** @brief Query whether the worker is allowed to drop results when the result queue is full.*/
SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_worker_get_drop_behavior(CUVIS_WORKER i_worker, CUVIS_INT* o_pCanDrop);


/** @private */
SDK_CAPI
CUVIS_STATUS SDK_CCALL cuvis_set_special(const char*);

/* (DE-) ALLOCATORS FOR WRAPPERS TO OTHER LANGAUGES (E.G. MATLAB) */

ALLOCATE_AND_FREE(CUVIS_IMBUFFER, imbuffer);
ALLOCATE_AND_FREE(CUVIS_GPS, gps);
ALLOCATE_AND_FREE(CUVIS_SENSOR_INFO, sensor_info);
ALLOCATE_AND_FREE(CUVIS_SESSION_INFO, session_info);
ALLOCATE_AND_FREE(CUVIS_MESU_METADATA, mesu_metadata);
ALLOCATE_AND_FREE(CUVIS_SAVE_ARGS, save_args);
ALLOCATE_AND_FREE(CUVIS_PROC_ARGS, proc_args);
ALLOCATE_AND_FREE(CUVIS_EXPORT_GENERAL_SETTINGS, export_general_settings);
ALLOCATE_AND_FREE(CUVIS_EXPORT_CUBE_SETTINGS, export_cube_settings);
ALLOCATE_AND_FREE(CUVIS_EXPORT_VIEW_SETTINGS, export_view_settings);
ALLOCATE_AND_FREE(CUVIS_EXPORT_TIFF_SETTINGS, export_tiff_settings);
ALLOCATE_AND_FREE(CUVIS_VIEWER_SETTINGS, viewer_settings);
ALLOCATE_AND_FREE(CUVIS_VIEW_DATA, view_data);
ALLOCATE_AND_FREE(CUVIS_COMPONENT_INFO, cuvis_component_info);
ALLOCATE_AND_FREE(CUVIS_WORKER_SETTINGS, worker_settings);

/* GETTER AND SETTER STUB GENERATION */

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_fps, double, "Frames per second");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_fps, double, "Frames per second");
ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_average, CUVIS_INT, "Number of averages");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_average, CUVIS_INT, "Number of averages");
ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_integration_time, double, "Integration time in milliseconds");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_integration_time, double, "Integration time in milliseconds");
ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_auto_exp, CUVIS_INT, "get_auto_exp");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_auto_exp, CUVIS_INT, "set_auto_exp");

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_auto_exp_comp, double, "get auto exposure compensation");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_auto_exp_comp, double, "set auto exposure compensation");

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_preview_mode, CUVIS_INT, "0 = disable, 1 = enable");
ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_preview_mode, CUVIS_INT, "0 = disable, 1 = enable");

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_operation_mode, CUVIS_OPERATION_MODE, "enumeration value");

ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_operation_mode, CUVIS_OPERATION_MODE, "enumeration value");

ACQ_SET_SINGLE_VALUE(cuvis_acq_cont_continuous, CUVIS_INT, "0 = stop, 1 = run");

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_bandwidth, CUVIS_INT, "bandwidth in MBit/s");

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_queue_size, CUVIS_INT, "size of measurement queue");

SDK_CAPI CUVIS_STATUS SDK_CCALL cuvis_acq_cont_queue_size_set(CUVIS_ACQ_CONT i_acqCont, CUVIS_INT i_size);

ACQ_GET_SINGLE_VALUE(cuvis_acq_cont_queue_used, CUVIS_INT, "used part of measurement queue");

COMP_GET_SINGLE_VALUE(cuvis_comp_online, CUVIS_INT, "0 = false, 1 = true");

COMP_GET_SINGLE_VALUE(cuvis_comp_temperature, CUVIS_INT, "temperature in degrees celsius");

COMP_GET_SINGLE_VALUE(cuvis_comp_bandwidth, CUVIS_INT, "bandwidth in MBit/s");

COMP_GET_SINGLE_VALUE(cuvis_comp_driver_queue_size, CUVIS_INT, "driver's internal receiving queue size");
COMP_GET_SINGLE_VALUE(cuvis_comp_driver_queue_used, CUVIS_INT, "driver's internal receiving queue used");
COMP_GET_SINGLE_VALUE(cuvis_comp_hardware_queue_size, CUVIS_INT, "internal hardware buffer size (if supported)");
COMP_GET_SINGLE_VALUE(cuvis_comp_hardware_queue_used, CUVIS_INT, "internal hardware buffer used (if supported)");

COMP_GET_SINGLE_VALUE(cuvis_comp_gain, double, "a.u.");

COMP_SET_SINGLE_VALUE(cuvis_comp_gain, double, "a.u.");

COMP_GET_SINGLE_VALUE(cuvis_comp_integration_time_factor, double, "factor to main integration time");

COMP_SET_SINGLE_VALUE(cuvis_comp_integration_time_factor, double, "factor to main integration time");

/** simple check function for error code */
#define CUVIS_CHECK(code)                                    \
  if (status_ok != (code))                                   \
  {                                                          \
    printf("Call failed. %s\n", cuvis_get_last_error_msg()); \
    return -1;                                               \
  }
;

/** helper macro for obtaining a pixel position from an imbuffer pointer */
#define IMBUFFER_GET(ptr, x, y, chn, imbuf) ptr[((y) * (imbuf).width + (x)) * (imbuf).channels + (chn)]

#ifdef __cplusplus
}
#endif

#undef ALLOCATE_AND_FREE
#undef ACQ_GET_SINGLE_VALUE
#undef ACQ_SET_SINGLE_VALUE
#undef COMP_GET_SINGLE_VALUE
#undef COMP_SET_SINGLE_VALUE

#endif
